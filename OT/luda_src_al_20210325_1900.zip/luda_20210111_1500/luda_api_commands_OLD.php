<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Api_Index(); } </script>
<script>
</script>
</head>

<body>

<?php $oDB  = new cLUDA_DB  (); ?>

<?php $wwwpath = LUDA_WWW_Site_Path_Get_01(); ?>

<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>

<main role="main">

<div class="container" >
    
    <?php
    //echo "<HR>";
    $max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
    //echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
    //echo "<HR>";
    
    //echo "<HR>";
    $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
    //echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
    //echo "<HR>";
    
    // Massimo codice (indipendentemente da SRV oppure UDA).
    $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
    //echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
    //echo "<HR>";
    ?>

  
 
    
    
    <?php
    echo "<HR />\n";
    
    $p_sTipo = "SRV";
    Stampa_Tabella_API_Test_01( $p_sTipo );
    echo "<BR />\n";
    
    $p_sTipo = "UDA";
    Stampa_Tabella_API_Test_01( $p_sTipo );
    echo "<BR />\n";
     
    echo "<HR />\n";
    ?>


<?php

function Stampa_Tabella_API_Test_01( $p_sTipo )
    {
    global $max_codice_SRV;
    global $max_codice_UDA;
    global $g_server_esploratori_qty;

$wwwpath = LUDA_WWW_Site_Path_Get_01();



$bDebug = FALSE;
$bDebug =  TRUE;
$bDebug = FALSE;
$bDebug =  TRUE;
$bDebug = FALSE;

    
    $l_oDB           = new cLUDA_DB  ();    
    $max_codice_SRV  = $l_oDB->GetMaxCodiceAPIbyTipo( "SRV" );
    $max_codice_UDA  = $l_oDB->GetMaxCodiceAPIbyTipo( "UDA" );
    $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
 
    echo "<TABLE border='1' >";
    echo "<TR class='cl_table_header_columns_name' >";
        echo "<TD colspan='100%' ><h2>API &bull; " .$p_sTipo. "</h2></TD>";
    echo "</TR>";  
    echo "<TR class='cl_table_header_columns_subname' >";
        echo "<TD colspan='2' ><h3>GET</h3></TD>";
        echo "<TD colspan='9' ><h3>PUT</h3></TD>";
    echo "</TR>";  
    for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
        {//for_esploratore_strt
        $idf_srv = "frm_srv_" .strtolower($p_sTipo). "_" .$esploratore;
        $idf_uda = "frm_uda_" .strtolower($p_sTipo). "_" .$esploratore;        
//      $url_srv = "/luda/api/" .strtolower($p_sTipo). "/get/?i=" .$esploratore;

if( 1 )
$url_srv = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/get/?i=" .$esploratore;
else
$url_srv = $wwwpath . strtolower($p_sTipo) . "/get/?i=" .$esploratore;

//echo "URLSRV = [<B>" .            LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/get/?i=" .$esploratore . "</B>]<BR>\n";
//echo "URLSRV = [<B>" . $wwwpath . LUDA_CONSTANT_SERVER_API_URL  . strtolower($p_sTipo) . "/get/?i=" .$esploratore . "</B>]<BR>\n";
//exit();
$url_srv = $wwwpath . LUDA_CONSTANT_SERVER_API_URL . strtolower($p_sTipo) . "/get/?i=" .$esploratore;
         
        echo "<TR>";
        
            // GET
            echo "<TD colspan='1' style=' QQQbackground:aquamarine; ' >";
            if( $bDebug )
                echo "<A href='" .$url_srv. "' target='" .$idf_srv. "' >" .strtolower($p_sTipo) . "/get/?i=" .$esploratore. "</A>";
                $srv_url = $url_srv;
                $srv_msg = strtolower($p_sTipo) . "/get/?i=" .$esploratore; 
                $srv_trg = $idf_srv;
                echo LUDA_HTML_Link_Show_02( $srv_url, $srv_msg, "div_" . $srv_trg );
            echo "</TD>";
            echo "<TD colspan='1' >";
            if( $bDebug )
                echo "<IFRAME id='" .$idf_srv. "' name='" .$idf_srv. "' QQQsrc='" .$url_srv. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
                echo "<DIV id='div_" .$idf_srv. "' name='div_" .$idf_srv. "'  style=' height:100px; overflow:scroll; width:200px; ' >- - -</DIV>";
            echo "</TD>";
            
            // PUT
            for( $codice = 0; $codice <= $max_codice_UDA; $codice++ )
                {//for_uda_strt
                
//$url_uda = "/luda/api/" .strtolower($p_sTipo). "/put/?i=" .$esploratore . "&k=" . $codice;
if( 0 )
$url_uda = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;
else
$url_uda = $wwwpath . strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;

$url_uda = $wwwpath . LUDA_CONSTANT_SERVER_API_URL . strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;


                echo "<TD colspan='1' >";
                if( $bDebug )
                    echo "<A href='" .$url_uda. "' target='" .$idf_uda. "' >" .strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice. "</A>";
                    $uda_url = $url_uda;
                    $uda_msg = strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;
                    $uda_trg = $idf_uda;
                    echo LUDA_HTML_Link_Show_02( $uda_url, $uda_msg, "div_" . $uda_trg );
                    
                echo "</TD>";
                }//for_uda_stop
            echo "<TD colspan='1' >";
            if( $bDebug )
                echo "<IFRAME id='" .$idf_uda. "' name='" .$idf_uda. "' QQQsrc='" .$url_uda. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
                echo "<DIV id='div_" .$idf_uda. "' name='div_" .$idf_uda. "' style=' height:100px; overflow:scroll; width:200px; ' >- - -</DIV>";
            echo "</TD>";
            
        echo "</TR>";  
          echo "<TR>";
            echo "<TD colspan='100%' >&nbsp;</TD>";
        echo "</TR>";  
        }//for_esploratore_stop
    echo "</TABLE>";
    }//Stampa_API_Test_01

?>

</div>
 
</main>

<footer>
</footer>
</BODY>
</HTML>