<?php
/*
$g_server_esploratori_qty = 5;

$g_color_gui_background = "#FFDA95"; // 255>FF 218>DA 149>95

function Test_01( )
{

}



function Test_02( )
  {

  $conn = new mysqli("localhost", "root", "", "dbluda");
  
  if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
  } 

  echo 'Connected to the database.<br>';

  $result = $conn->query("SELECT * FROM luda_server_stati; ");

  echo "Number of rows: $result->num_rows";



 
if ($result = $conn->query("SELECT * FROM luda_server_stati ")) {
    printf("Select returned %d rows.\n", $result->num_rows);



        echo "<TABLE border='1' >";
        while($obj = $result->fetch_object()){
            //var_dump( $obj );
            $line ="";
            $line.="<TR >";
            $line.="<TD >" . $obj->idstato     . "</TD>";
            $line.="<TD >" . $obj->codice      . "</TD>";
            $line.="<TD >" . $obj->descrizione . "</TD>";
            $line.="<TD >" . $obj->stato       . "</TD>";
            $line.="<TD >" . $obj->note        . "</TD>";
            $line.="</TR>";
            echo $line;
        }
        echo "</TABLE>";
         
    $result->close();
}
       
 
  $conn->close();
  }//Test_02






function Test_03( )
  {

  $conn = new mysqli("localhost", "root", "", "dbluda");
  
  if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
  } 
 
 
if ($result = $conn->query("SELECT * FROM luda_server_api_codici ")) {
    printf("Select returned %d rows.\n", $result->num_rows);



        echo "<TABLE border='1' >";
        while($obj = $result->fetch_object()){
            //var_dump( $obj );
            $line ="";
            $line.="<TR >";
            $line.="<TD >" . $obj->tipo     . "</TD>";
            $line.="<TD >" . $obj->codice      . "</TD>";
            $line.="<TD >" . $obj->funzione . "</TD>";
            $line.="<TD >" . $obj->num_parametri . "</TD>";
            $line.="<TD >" . $obj->nome      . "</TD>";
            $line.="<TD >" . $obj->descrizione . "</TD>";
            $line.="<TD >" . $obj->note        . "</TD>";
            $line.="</TR>";
            echo $line;
        }
        echo "</TABLE>";
         
    $result->close();
}

 
  $conn->close();
  }//Test_03
*/

?>


<?php












    /*
    // property declaration
    public $var = 'a default value';

    private $mDB_conn = NULL;  // Connessione al Database.
    
    private $mDB_result = NULL;  // Result of (last executed) query.
    
    private $mDB_record_count = 0;  // Record count (dell'ultima query).
    
    function __construct() {
        //print "cLUDA_DB :: constructor\n";
        
        $this->mDB_conn = new mysqli("localhost", "root", "", "dbluda");
  
    if ($this->mDB_conn->connect_error) {
        die("ERRORE: Impossibile connettersi al DataBase: [" . $this->mDB_conn->connect_error . "]" );
        } 
      
    }//__construct

    public function Query_01( $p_sQuery )
        {
        $this->mDB_result = $this->mDB_conn->query( $p_sQuery );
    
        $this->mDB_record_count = $this->mDB_result->num_rows;
        
        //echo "Number of rows: " . $this->mDB_record_count . "";
    
        return $this->mDB_result;
        }//Query_01     
 
    public function RecordCount_01( )
        {
        return $this->mDB_record_count . "";
        }//RecordCount_01     
 
 
    public function ColumnsName_01( )
        {
        $aColumnsName = Array();
        
        $values = $this->mDB_result->fetch_all(MYSQLI_ASSOC);

$b_seek_zero = $this->mDB_result->data_seek (0);
//$columns = array();

        if(!empty($values)){
            $aColumnsName = array_keys($values[0]);
            }
        
        // Return value.
        return $aColumnsName;
        
        }//RecordCount_01

    public function Result_01( )
        {
        return $this->mDB_result;
        }//Result_01     
 

    public function Fetch_01( )
        {
        $obj = $this->mDB_result->fetch_object();
        return $obj;
        }//Fetch_01
 
    public function GetMaxCodiceAPIbyTipo( $p_sTipo )
        {
        $query = "SELECT MAX(codice) AS max_codice_tipo FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' ";
        echo "QUERY = [" .$query. "]<BR>\n";
        $this->Query_01( $query );
        $result = $this->Fetch_01();
        //var_dump( $result );
        //exit();
        $max_codice_tipo = $result->max_codice_tipo;
        return $max_codice_tipo;
    }//GetMaxCodiceAPIbyTipo    
    

    public function GetMaxCodiceAPIbyTipoAndFunzione( $p_sTipo, $p_sFunzione )
        {
        $query = "SELECT MAX(codice) AS max_codice_tipo FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND funzione = '" .$p_sFunzione. "' ";
        echo "QUERY = [" .$query. "]<BR>\n";
        $this->Query_01( $query );
        $result = $this->Fetch_01();
        //var_dump( $result );
        //exit();
        $max_codice_tipo = $result->max_codice_tipo;
        return $max_codice_tipo;
    }//GetMaxCodiceAPIbyTipoAndFunction    
///////////////////////////////////////////////////////////////////
        
    function Table_Print_01( $p_sTableName )
        {
        $loDB = new cLUDA_DB();
        $query = "SELECT * FROM " . $p_sTableName;
        $result = $loDB->Query_01($query);
        $num_records = $loDB->RecordCount_01();
        $columns_name = $loDB->ColumnsName_01();
        //var_dump( $columns_name );
        //exit();
        
        echo "Tabella <b>'" .$p_sTableName. "'</b> &bull; Numero di records = <b>[" . $num_records . "]</b><br>";
    
        // Select queries return a resultset.
        if ( ! is_null($result) ) 
            {
            //printf( "Il recordset contiene [%d] righe.\n", $num_records );
            echo "<TABLE border='1' >";
            
            // Header.
            $line  = "";
            $line .= "<TR class='cl_table_header_columns_name' >";
            foreach( $columns_name as $col_num => $col_name )
                {
                $line .= "<TD >" .$col_name. "</TD>";
                }
            $line .= "</TR>";
            echo $line;
          
            // Data.
            while( $obj = $loDB->Fetch_01() )
                {
                //var_dump( $obj );
                $line ="";
                $line.="<TR >";
                foreach( $columns_name as $col_num => $col_name )
                    {
                    $line .= "<TD >" . $obj->$col_name . "</TD>";
                    }
                $line.="</TR>";
                echo $line;
                }
            echo "</TABLE>";
            }
          
        }//Table_Print_01
///////////////////////////////////////////////////////////////////
    
    public function Finish_01( )
        {//Finish_01
                            
        //
        $this->mDB_result->close();
       
        $this->mDB_conn->close();
        }//Finish_01
///////////////////////////////////////////////////////////////////

    // method declaration
    public function displayVar() {
        echo $this->var;
    }
///////////////////////////////////////////////////////////////////
*/



?>