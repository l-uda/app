<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Status_Index(); } </script>
<script>
</script>
</head>

<?php
//echo "<H1 >LUDA &bull; Status</H1>\n";
//echo "<H2 >(2020-03-30 :: 22:15)</H1>\n";
//echo "<HR />";                                      
//echo "<A href='update' >Update Service...</A>";
//echo "<BR />\n";
?>


<body>
  

<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>

<main role="main">

<div class="container" >

 

<?php $oDB = new cLUDA_DB(); ?>



<HR />
<A href='img/CPIM_LUDA_Status_20200201B.png' target='_blank' ><IMG src='img/CPIM_LUDA_Status_20200201B.png' /></A>
<HR />

<?php
/*
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  0 , 'GNP' , 0 , 'IDLE'         , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  1 , 'GNP' , 0 , 'WAIT_APP'     , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  2 , 'GNP' , 0 , 'GRP_SENT'     , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  3 , 'GNP' , 0 , 'REACH_UDA'    , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  4 , 'GNP' , 0 , 'REACHING_UDA' , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  5 , 'GNP' , 0 , 'READY'        , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  6 , 'GNP' , 0 , 'START'        , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  7 , 'GNP' , 0 , 'STARTED'      , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  8 , 'GNP' , 0 , 'PAUSE'        , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' ,  9 , 'GNP' , 0 , 'PAUSED'       , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 10 , 'GNP' , 0 , 'ABORT'        , '' , NULL ); 
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 11 , 'GNP' , 0 , 'ABORTED'      , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 12 , 'GNP' , 0 , 'RESTART'      , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 13 , 'GNP' , 0 , 'WAIT_DATA'    , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 14 , 'GNP' , 0 , 'DATA_SENT'    , '' , NULL ); 
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 15 , 'GNP' , 0 , 'COMPLETED'    , '' , NULL ); 
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 16 , 'GNP' , 0 , 'FINALIZE'     , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 17 , 'GNP' , 0 , 'FINALIZED'    , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 20 , 'GNP' , 0 , 'ERROR_UDA'    , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 21 , 'GNP' , 0 , 'ERROR_APP'    , '' , NULL );
 INSERT INTO luda_server_api_codici VALUES ( 'COD' , 22 , 'GNP' , 0 , 'ERROR_SERVER' , '' , NULL );
*/
?>
    
    

<HR>
<A href='img/LUDA_server_API_info_01.png' target='_blank' ><IMG src='img/LUDA_server_API_info_01.png' ></A>
<HR>




<?php


//echo "<HR>";
$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
//echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//echo "<HR>";

//echo "<HR>";
$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
//echo "<HR>";

// Massimo codice (indipendentemente da SRV oppure UDA).
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
//echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
//echo "<HR>";

?>




<TABLE border='1' >
<TR >
<?php

// Codici SERVER :: GET.
$api_tipo     = "SRV";
$api_funzione = "GET";
echo "<TD style=' vertical-align:top; ' >";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
echo "</TD>";

// Codici SERVER :: PUT.
$api_tipo     = "SRV";
$api_funzione = "PUT";
echo "<TD style=' vertical-align:top; ' >";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
echo "</TD>";

// Codici UDA :: GET.
$api_tipo     = "UDA";
$api_funzione = "GET";
echo "<TD style=' vertical-align:top; ' >";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
echo "</TD>";

// Codici UDA :: PUT.
$api_tipo     = "UDA";
$api_funzione = "PUT";
echo "<TD style=' vertical-align:top; ' >";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
echo "</TD>";

?>
</TR>
</TABLE >




<?php

//Test_02();

//Test_03();




function StampaTabellaCodici_01( $p_sTipo )
    {
    $loDB = new cLUDA_DB();

    echo "<H3>CODICI &bull; " .$p_sTipo. " UDA</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD >GET(i)</TD><TD >PUT(i,k)</TD></TR>";    
    $max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
    for( $ccc = 0; $ccc <= $max_codice_tipo; $ccc++ )
        {//for_strt
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' ORDER BY codice, funzione ";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo. ")</TD></TR>";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_GET = $loDB->Fetch_01();
        $recordset_PUT = $loDB->Fetch_01();
        echo "<TR>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_GET ); echo "</TD>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        echo "<TR >";
            if( is_null($recordset_GET) )
                {
                $data_GET  = "";
                }
            else
                {
                $data_GET  = "";
                $data_GET .= $recordset_GET->codice;
                $data_GET .= ": ";
                $data_GET .= $recordset_GET->nome;
                $data_GET .= "<br>";
                $data_GET .= $recordset_GET->funzione;
                $data_GET .= ($recordset_GET->num_parametri == "1" ? "(i)"   : "");
                $data_GET .= "";
                }
            if( is_null($recordset_PUT) )
                {
                $data_PUT  = "";
                }
            else
                {
                $data_PUT  = "";
                $data_PUT .= $recordset_PUT->codice;
                $data_PUT .= ": ";
                $data_PUT .= $recordset_PUT->nome;
                $data_PUT .= "<br>";
                $data_PUT .= $recordset_PUT->funzione;
                $data_PUT .= ($recordset_PUT->num_parametri == "2" ? "(i,k)" : "");
                $data_PUT .= "";
                }
            echo "<TD >" .$data_GET. "</TD>";
            echo "<TD >" .$data_PUT. "</TD>";
        echo "</TR>";
        echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_01
    


function StampaTabellaCodici_02( $p_sTipo, $p_sFunzione )
    {
    $loDB = new cLUDA_DB();
    //echo "<H3>CODICI: " .$p_sTipo. " API &bull; " .$p_sFunzione. "</H3>\n";
    echo "<H3>" .$p_sTipo. " API &bull; " .$p_sFunzione. "</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD>Code:</TD><TD>Name:</TD><TD >GET(i) / PUT(i,k)</TD></TR>";    
    //$max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
    $max_codice_tipo_and_function = $loDB->GetMaxCodiceAPIbyTipoAndFunzione( $p_sTipo, $p_sFunzione );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
     
    for( $ccc = 0; $ccc <= $max_codice_tipo_and_function; $ccc++ )
        {//for_strt
        
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' AND funzione = '" .$p_sFunzione. "' ORDER BY codice ";
        //echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
       
        
        //echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo_and_function. ")</TD></TR>";
        //echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_function = $loDB->Fetch_01();
        //$recordset_PUT = $loDB->Fetch_01();
        /*
        echo "<TR>";
            echo "<TD colspan='100%' style=' background:gray; ' >"; var_dump( $recordset_function ); echo "</TD>";
            //echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        */
        echo "<TR >";
            if( is_null($recordset_function) )
                {
                $data_function  = "";
                }
            else
                {
                $data_function  = "";
                $data_function .= "<td>";
                $data_function .= $recordset_function->codice;
                $data_function .= ": ";
                $data_function .= "</td>";
                $data_function .= "<td>";
                $data_function .= $recordset_function->nome;
                //$data_function .= "<br>";
                $data_function .= "</td>";
                $data_function .= "<td>";
                $data_function .= $recordset_function->funzione;
                $data_function .= ($recordset_function->num_parametri == "1" ? "(i)"   : "");
                $data_function .= ($recordset_function->num_parametri == "2" ? "(i,k)" : "");
                $data_function .= "</td>";
                $data_function .= "";
                }
//            echo "<TD colspan='100%' >" .$data_function. "</TD>";
            echo $data_function;
        echo "</TR>";
        //echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_02
    



?>


</div>
 
</main>

<footer>
</footer>
</BODY>
</HTML>