<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Layout_Index(); } </script>
<script>
</script>
</head>

<body>
  

<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>

<?php $wwwpath = LUDA_WWW_Site_Path_Get_01(); ?>

<main role="main">

<div class="container" >

<!--
<a href='https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-35448/zapsplat_multimedia_button_press_plastic_click_004_36871.mp3?_=4' >down...</a>    
!-->    
    
    <CENTER >
    <DIV id='div_server_master_controls' >
    <TABLE border='0' cellpadding='10' cellspacing=0 id='table_server_master_controls' >
    
        <TR>
            <TD colspan='4' style=' font-size:20px; font-weight:bold; text-align:center; ' > 
                            <!--
                            <CENTER ><a href='index.php' ><H1 >LUDA</H1></a></CENTER>
                            !-->
                            <CENTER >
                            <?php
                            $url = $wwwpath . "index.php";
                            //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >LUDA</a>";
                            //echo LUDA_HTML_Link_Show_02( $url, "LUDA", '_blank' );
                            echo LUDA_HTML_Link_Show_02( $url, "LUDA" );
                            ?>
                          </CENTER>
            </TD>
        </TR>
  
        <TR>
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
              <CENTER >Titolo Pagina</CENTER>
            <hr></TD>
        </TR>
     
        <TR>
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
              <h1 >Titolo Pagina 1</h1>
              <h2 >Titolo Pagina 2</h2>
              <h3 >Titolo Pagina 3</h3>
              <h4 >Titolo Pagina 4</h4>
              <h5 >Titolo Pagina 5</h5>
              <h6 >Titolo Pagina 6</h6>
            <hr></TD>
        </TR>
       
    </TABLE></DIV>
    </CENTER>
 
</div>
 
</main>

<footer>
</footer>
</BODY>
</HTML>