<?php
//echo "API::APP::GET<BR>";
//session_start();
//require_once( "../../../luda_include_config.php"    );
//require_once( "../../../luda_include_functions.php" );
//require_once( "../../../luda_class_db.php"          );
//require_once( "../../../luda_class_api.php"         );

// Ritorna la lista degli ID delle UDA completate dalla APP in questione.

function LUDA_API_APP_CMD_CompletedList_Get_01( $p_iAppId )
    {
    
    
    
// Parameters.
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_APP;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GET;

//print_r( $_GET );
//echo "<BR>";
//$par_iI   = LUDA_API_Parameters_GetFromREST( $_GET, 'i'    );
//$par_iK   = LUDA_API_Parameters_GetFromREST( $_GET, 'k'    );
//$par_data = LUDA_API_Parameters_GetFromREST( $_GET, 'data' );

// Object.
$oAPI = new cLUDA_API( $l_sTipo );
//if( $l_sFunzione == LUDA_CONSTANT_SERVER_FUNZIONE_PUT ) { $stato = $oAPI->Put_02( $par_iI, $par_iK ); $stato = $oAPI->Get_02( $par_iI ); }
//if( $l_sFunzione == LUDA_CONSTANT_SERVER_FUNZIONE_GET ) {                                             $stato = $oAPI->Get_02( $par_iI ); }
//echo "STATO = <B >[" .$stato. "]</B>";
//echo "<BR>";
$item = $oAPI->Get_03( $p_iAppId );
//var_dump( $item );    
    
//return -1234567890;    
    
//$app_id               = $item->idapp;
$app_status_code      = $item[ 'stato_by_app']     ;
$app_status_data      = $item[ 'data_by_app']      ;
$app_status_completed = $item[ 'completed_by_app'] ;

 
//$stato_by_app = -1234543210;
//$data_by_app  = "WIP CHECK here il codice dello status dell'intera installazione...";
//$completed_by_app = "1,2,3,4,5,6,7,8,9,147";
    $item = Array();
    //$item[ 'status'           ] = $stato_by_app     ;
    $item[ 'stato_by_app'     ] = $app_status_code     ;
    $item[ 'data_by_app'      ] = $app_status_data      ;
    $item[ 'completed_by_app' ] = $app_status_completed ;

    // Return value.
    return $item;

    }//LUDA_API_APP_CMD_CompletedList_Get_01



?>