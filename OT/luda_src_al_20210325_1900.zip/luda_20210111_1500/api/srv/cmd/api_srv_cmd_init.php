<?php
// INIT: vedi "init_or_reboot" (dato che il codice e' -per-adesso- identico)
?>