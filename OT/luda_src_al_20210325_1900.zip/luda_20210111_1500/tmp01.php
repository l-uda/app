<PRE >

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE `luda_server_stati` (
  `idstato` int(11) NOT NULL auto_increment,
  `codice` varchar(16) default NULL,
  `descrizione` varchar(64) NOT NULL,
  `stato` int(11) default '0',
  `note` varchar(256) NOT NULL,
  PRIMARY KEY  (`idstato`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(1, 'UDA1', 'Postazione UDA N.1', 0, 'Gestione della Postazione UDA N.1');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(2, 'UDA2', 'Postazione UDA N.2', 0, 'Gestione della Postazione UDA N.2');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(3, 'UDA3', 'Postazione UDA N.3', 0, 'Gestione della Postazione UDA N.3');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(4, 'UDA4', 'Postazione UDA N.4', 0, 'Gestione della Postazione UDA N.4');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(5, 'UDA5', 'Postazione UDA N.5', 0, 'Gestione della Postazione UDA N.5');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(6, 'MSTR', 'Postazione Master!', 0, 'Gestione della Postazione Master!');

</PRE>


<?php

exit();
 
if( 0 )
{
$homepage = file_get_contents( "http://localhost/" );
echo $homepage;
}
 

if( 0 )
{
$homepage = file_get_contents( "http://localhost/phpmyadmin/" );
echo $homepage;
}


?>