<?php
///////////////////////////////////////////////////////////////////
// 
// BoF :: "luda_class_api.PHP"
// 
// 2020-12-01 :: 15:00
// 2020-04-04 :: 19:00
// 
///////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////

Class cLUDA_API
    {

    // Tipo della API (che effettua la richiesta REST): "SRV" oppure "UDA" oppure "APP".
    private $m_sSelfTipo = "";

    // Database object.
    private $m_oDB = NULL;

    function __construct( $p_sSelfTipo ) {
        //print "cLUDA_API :: constructor<br>\n";
  
       $this->m_oDB = new cLUDA_DB();
  
    // Tipo della API.
    if( ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_COD) && 
        ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_UDA) && 
        ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_SRV) && 
        ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_APP)    )
        {
        echo "ATTENZIONE: il Tipo <b>[" .$p_sSelfTipo. "]</b> della API deve essere: <I>'SRV'</I> oppure <I>'UDA'</I> oppure <I>'APP'</I> !!!";
        exit();
        return FALSE;
        }
    $this->m_sSelfTipo = $p_sSelfTipo;
  
    }//__construct

    function __destruct() 
        {
        $this->m_oDB->Finish_01();
        }//__destruct


    public function Get_01( $p_iI )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $stato = $this->_Get_SelfSrv_01($p_iI); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $stato = $this->_Get_SelfUda_01($p_iI); } 
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $stato = $this->_Get_SelfApp_01($p_iI); } 
        return $stato; 
        }//Get_01
    public function Get_02( $p_iI )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $stato = $this->_Get_SelfSrv_02($p_iI); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $stato = $this->_Get_SelfUda_02($p_iI); } 
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $stato = $this->_Get_SelfApp_02($p_iI); } 
        return $stato; 
        }//Get_02
    public function Get_03( $p_iI )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $item = $this->_Get_SelfSrv_03($p_iI); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $item = $this->_Get_SelfUda_03($p_iI); } 
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $item = $this->_Get_SelfApp_03($p_iI); } 
        //echo "NOP_WIP";
        //exit();
        return $item; 
        }//Get_03
        
    private function _Get_SelfSrv_01( $p_iI )
        {
        switch( $this->m_sSelfTipo )
            {//sw_strt
            case LUDA_CONSTANT_SERVER_TIPO_SRV:
                $query = "SELECT stato_by_uda FROM luda_server_stati_uda WHERE iduda = $p_iI ";
                //echo "WARNING: _Get_SelfSrv_01: DEFAULT? SERVER?";
                //return -147; // CODICE DI ERRORE ***INVENTATO*** !!!
                break;
            case LUDA_CONSTANT_SERVER_TIPO_UDA:
                $query = "SELECT stato_by_uda FROM luda_server_stati_uda WHERE iduda = $p_iI ";
                break;
            case LUDA_CONSTANT_SERVER_TIPO_APP:
                $query = "SELECT stato_by_app FROM luda_server_stati_app WHERE idapp = $p_iI ";
                break;
            }//sw_stop
        //echo "QUERY = [" . $query  . "]<br>";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_uda;
        switch( $this->m_sSelfTipo )
            {//sw_strt
            case LUDA_CONSTANT_SERVER_TIPO_SRV:
                $stato = $record->stato_by_uda;
                //echo "WARNING: _Get_SelfSrv_01: DEFAULT? SERVER?";
                //$stato = -147; // CODICE DI ERRORE ***INVENTATO*** !!!
                break;
            case LUDA_CONSTANT_SERVER_TIPO_UDA:
                $stato = $record->stato_by_uda;
                break;
            case LUDA_CONSTANT_SERVER_TIPO_APP:
                $stato = $record->stato_by_app;
                break;
            }//sw_stop

        //print_r( $stato );
        //exit();        
        return $stato;
        }//_Get_SelfSrv_01
    private function _Get_SelfSrv_02( $p_iI )
        {
        $query = "SELECT stato_by_srv FROM luda_server_stati_srv WHERE idsrv = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_srv;
        //print_r( $stato );
        return $stato;
        }//_Get_SelfSrv_02 
    private function _Get_SelfSrv_03( $p_iI )
        {
//     $query = "SELECT stato_by_srv FROM luda_server_stati_srv WHERE idsrv = $p_iI ";
        $query = "SELECT * FROM luda_server_stati_srv WHERE idsrv = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato_by_srv = $record->stato_by_srv ;
        $data_by_srv  = $record->data_by_srv  ;
        $item = Array();
        $item[ 'status'       ] = $stato_by_srv ;
        $item[ 'stato_by_srv' ] = $stato_by_srv ;
        $item[ 'data_by_srv'  ] = $data_by_srv  ;
        //print_r( $stato );
        return $item;
        }//_Get_SelfSrv_03 

         
        
    private function _Get_SelfUda_01( $p_iI )
        {
        $query = "SELECT stato_by_srv FROM luda_server_stati_uda WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_srv;
        //print_r( $stato );
        return $stato;
        }//_Get_SelfUda_01
    private function _Get_SelfUda_02( $p_iI )
        {
        $query = "SELECT stato_by_uda FROM luda_server_stati_uda WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_uda;
        //print_r( $stato );
        return $stato;
        }//_Get_SelfUda_02
    private function _Get_SelfUda_03( $p_iI )
        {
        //$query = "SELECT stato_by_uda FROM luda_server_stati_uda WHERE iduda = $p_iI ";
        $query = "SELECT * FROM luda_server_stati_uda WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato_by_uda = $record->stato_by_uda ;
        $data_by_uda  = $record->data_by_uda  ;
        $item = Array();
        $item[ 'status'       ] = $stato_by_uda ;
        $item[ 'stato_by_uda' ] = $stato_by_uda ;
        $item[ 'data_by_uda'  ] = $data_by_uda  ;
        //print_r( $stato );
        return $item;
        }//_Get_SelfUda_03
        
            
           
    private function _Get_SelfApp_01( $p_iI )
        {
        //$this->_API_Tipo_Get_01( $p_iI );
        $query = "SELECT stato_by_srv FROM luda_server_stati_app WHERE idapp = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_srv;
        //print_r( $stato );
        return $stato;
        }//_Get_SelfApp_01     
    private function _Get_SelfApp_02( $p_iI )
        {
        $query = "SELECT stato_by_app FROM luda_server_stati_app WHERE idapp = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        $stato = $record->stato_by_app;
        //print_r( $stato );
        return $stato;
        }//_Get_SelfApp_02
    private function _Get_SelfApp_03( $p_iI )
        {
        
        if( $p_iI == -1 )
            {
            require_once( "./api_uda_get_minus_one.php" );
            $item = LUDA_API_GET_Minus_one_01();
            return $item;
        }
        
        
        //$query = "SELECT stato_by_app FROM luda_server_stati_app WHERE idapp = $p_iI ";
        $query = "SELECT * FROM luda_server_stati_app WHERE idapp = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        //$stato = $record->stato_by_app;
        //print_r( $stato );
        //return $stato;        
        $stato_by_app      = $record->stato_by_app     ;
        $data_by_app       = $record->data_by_app      ;
        $completed_by_app  = $record->completed_by_app ;
        $item = Array();
        $item[ 'status'           ] = $stato_by_app     ;
        $item[ 'stato_by_app'     ] = $stato_by_app     ;
        $item[ 'data_by_app'      ] = $data_by_app      ;
        $item[ 'completed_by_app' ] = $completed_by_app ;
        //print_r( $stato );
        return $item;                
        }//_Get_SelfApp_03
        
  

    public function Put_01( $p_iI, $p_iK )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $this->_Put_SelfSrv_01($p_iI,$p_iK); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $this->_Put_SelfUda_01($p_iI,$p_iK); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $this->_Put_SelfApp_01($p_iI,$p_iK); }  
        }//Put_01
    public function Put_02( $p_iI, $p_iK )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $this->_Put_SelfSrv_02($p_iI,$p_iK); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $this->_Put_SelfUda_02($p_iI,$p_iK); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $this->_Put_SelfApp_02($p_iI,$p_iK); }  
        }//Put_02
    public function Put_03( $p_iI, $p_iK, $p_data="" )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $this->_Put_SelfSrv_03($p_iI,$p_iK,$p_data); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $this->_Put_SelfUda_03($p_iI,$p_iK,$p_data); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_APP ) { $this->_Put_SelfApp_03($p_iI,$p_iK,$p_data); }  
        }//Put_03
        
        
        
    private function _Put_SelfSrv_01( $p_iI, $p_iK )
        {
        switch( $this->m_sSelfTipo )
            {//sw_strt
            case LUDA_CONSTANT_SERVER_TIPO_SRV:
                //echo "WARNING: _Put_SelfSrv_01: DEFAULT? SERVER?";
                $query = "UPDATE luda_server_stati_uda SET stato_by_srv = $p_iK WHERE iduda = $p_iI ";
                break;
            case LUDA_CONSTANT_SERVER_TIPO_UDA:
                $query = "UPDATE luda_server_stati_uda SET stato_by_srv = $p_iK WHERE iduda = $p_iI ";
                break;
            case LUDA_CONSTANT_SERVER_TIPO_APP:
                $query = "UPDATE luda_server_stati_app SET stato_by_srv = $p_iK WHERE idapp = $p_iI ";
                break;
            }//sw_stop
        $this->m_oDB->Query_01($query);
        }//_Put_SelfSrv_01
    private function _Put_SelfSrv_02( $p_iI, $p_iK )
        {
        $query = "UPDATE luda_server_stati_srv SET stato_by_srv = $p_iK WHERE idsrv = $p_iI ";
        $this->m_oDB->Query_01($query);
        }//_Put_SelfSrv_02
    private function _Put_SelfSrv_03( $p_id, $p_stato, $p_data="" )
        {
        if( $p_data=="" )
            $query = "UPDATE luda_server_stati_srv SET stato_by_srv = $p_stato                           WHERE idsrv = $p_id ";
        else
            $query = "UPDATE luda_server_stati_srv SET stato_by_srv = $p_stato , data_by_srv = '$p_data' WHERE idsrv = $p_id ";
//echo $query;
        $this->m_oDB->Query_01($query);
        }//_Put_SelfSrv_03
        
    private function _Put_SelfUda_01( $p_iI, $p_iK )
        {
        $query = "UPDATE luda_server_stati_uda SET stato_by_uda = $p_iK WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        }//_Put_SelfUda_01
    private function _Put_SelfUda_02( $p_iI, $p_iK )
        {
        $query = "UPDATE luda_server_stati_uda SET stato_by_uda = $p_iK WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        }//_Put_SelfUda_02
    private function _Put_SelfUda_03( $p_id, $p_stato, $p_data="" )
        {
        if( $p_data=="" )
            $query = "UPDATE luda_server_stati_uda SET stato_by_uda = $p_stato                           WHERE iduda = $p_id ";
        else
            $query = "UPDATE luda_server_stati_uda SET stato_by_uda = $p_stato , data_by_uda = '$p_data' WHERE iduda = $p_id ";
//echo $query;
        $this->m_oDB->Query_01($query);
        }//_Put_SelfUda_03
    
    private function _Put_SelfApp_01( $p_iI, $p_iK )
        { 
        $query = "UPDATE luda_server_stati_app SET stato_by_app = $p_iK WHERE idapp = $p_iI ";
        $this->m_oDB->Query_01($query);
        }//_Put_SelfApp_01 
    
    private function _Put_SelfApp_02( $p_iI, $p_iK )
        { 
        $query = "UPDATE luda_server_stati_app SET stato_by_app = $p_iK WHERE idapp = $p_iI ";
        $this->m_oDB->Query_01($query);
        }//_Put_SelfApp_02 
    private function _Put_SelfApp_03( $p_id, $p_stato, $p_data="" )
        {
        //var_dump( $p_data );
        if( $p_data=="" )
            $query = "UPDATE luda_server_stati_app SET stato_by_app = $p_stato                           WHERE idapp = $p_id ";
        else
            $query = "UPDATE luda_server_stati_app SET stato_by_app = $p_stato , data_by_app = '$p_data' WHERE idapp = $p_id ";
//echo $query;
        $this->m_oDB->Query_01($query);
        }//_Put_SelfApp_03 
 

    // Ritorna un array contenente gli Stati
    //  relativi all'Object indicato ('UDA', 'APP', 'SRV')
    //  ed al Type indicato ('GET', 'PUT').
    public function Stati_Array_Get_01( $p_sSubject, $p_sFunction )
        {
        $query  = "";        
        $query .= "SELECT   * ";
        $query .= "FROM     luda_server_api_codici ";
        $query .= "WHERE    tipo     = '" . $p_sSubject  . "' ";
        $query .= "AND      funzione = '" . $p_sFunction . "' ";
        $query .= "ORDER BY nome ";
        $query .= "";
        //echo $query;
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        
        //$record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        
        // Lista degli Stati.
        $l_aStati = Array();
        while( $record = $this->m_oDB->Fetch_01() )
            {//while_strt
//print_r( $record );  
//exit();
            $stato_codice = $record->codice;
            $stato_nome   = $record->nome;
            $item = Array();
            $item[ 'codice' ] = $stato_codice ;
            $item[ 'nome'   ] = $stato_nome   ;
            $l_aStati[ $stato_codice ] = $item;
            }//while_stop

        // Return value.
        return $l_aStati;
        
    }//Stati_Array_Get_01

   
    // Ritorna un array contenente gli Stati
    //  relativi all'Object indicato ('UDA', 'APP', 'SRV')
    //  ed al Type indicato ('GET', 'PUT').
    public function Stati_Array_Get_02( $p_sSubject, $p_sFunction )
        {
        $query  = "";        
        $query .= "SELECT   * ";
        $query .= "FROM     luda_server_api_codici ";
        $query .= "WHERE    tipo     = '" . $p_sSubject  . "' ";
        $query .= "AND      funzione = '" . $p_sFunction . "' ";
        $query .= "ORDER BY nome ";
        $query .= "";
        //echo $query;
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //print_r( $recordset );
        
        //$record = $this->m_oDB->Fetch_01();
        //print_r( $record );
        
        // Lista degli Stati.
        $l_aStati = Array();
        while( $record = $this->m_oDB->Fetch_01() )
            {//while_strt
//print_r( $record );  
//exit();
            $apicodici_tipo          = $record->tipo          ;
            $apicodici_codice        = $record->codice        ;
            $apicodici_funzione      = $record->funzione      ;
            $apicodici_num_parametri = $record->num_parametri ;
            $apicodici_num_ritorni   = $record->num_ritorni   ;
            $apicodici_nome          = $record->nome          ;
            $apicodici_descrizione   = $record->descrizione   ;
            $apicodici_note          = $record->note          ;            
            $stato_codice            = $record->codice;
            $stato_nome              = $record->nome;
            $item = Array();
            $item[ 'tipo'          ] = $apicodici_tipo          ;
            $item[ 'codice'        ] = $apicodici_codice        ;
            $item[ 'funzione'      ] = $apicodici_funzione      ;
            $item[ 'num_parametri' ] = $apicodici_num_parametri ;
            $item[ 'num_ritorni'   ] = $apicodici_num_ritorni   ;
            $item[ 'nome'          ] = $apicodici_nome          ;
            $item[ 'descrizione'   ] = $apicodici_descrizione   ;
            $item[ 'note'          ] = $apicodici_note          ;            
            $item[ 'codice'        ] = $stato_codice ;
            $item[ 'nome'          ] = $stato_nome   ;
            $l_aStati[ $stato_codice ] = $item;
            }//while_stop

        // Return value.
        return $l_aStati;
        
    }//Stati_Array_Get_02
    
    
    public function Stato_GetCodiceByNome_01( $p_sNome )
        { 
        //echo "WIP_Stato_GetCodiceByNome_01::[" .$p_sNome. "]<br>";
        
         // API::UDA::PUT
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_COD;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GNP; 
        //$oAPI = new cLUDA_API( $l_sTipo ); 
        $l_aStati = $this->Stati_Array_Get_01( strtoupper($l_sTipo), $l_sFunzione );
        ksort( $l_aStati );
        $g_aStatiGnp = $l_aStati;
 
        {// if_strt
        $sJsonAPI = json_encode( $aJsonAPI['list'][$par_sType][-1] );
        //foreach( $aJsonAPI['list'][$par_sType] as $codice => $item )
        foreach( $g_aStatiGnp as $codice => $item )
            {
            // Cerca l'indice tramite il contenuto (associativo) del 'nome'.
            //var_dump( $item );
            $l_iCodice = $item[ 'codice' ];      
            $l_sNome   = $item[ 'nome'   ];      
            //var_dump( $l_iCodice );
            if( $l_sNome == $p_sNome )
                {
                //$sJsonAPI = json_encode( $aJsonAPI['list'][$par_sType][$l_iCodice] );
                $sJsonAPI = json_encode( $item );
                //var_dump( $sJsonAPI );
                //echo "FOUND:" . $p_sNome ;
                return $item;
                //continue;
                }
            }; 
        }//if_stop


echo "NOT FOUND:" . $p_sNome ;
return "Stato_GetCodiceByNome_01_NOT_FOUND: " . $p_sNome;
        
// Return data.
echo $sJsonAPI;
//echo "exited337";
//exit();
        $rv = $sJsonAPI;
        $rv = $item;
        
        // Return value.
        return $rv;
        
        
        
        }//Stato_GetCodiceByNome_01        
    
    public function Stato_GetNomeByCodice_01( $p_sCodice )
        { 
        //echo "Stato_GetNomeByCodice_01::[" .$p_sCodice. "]<br>";
        $l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_COD;
        $l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GNP; 
        $l_aStati = $this->Stati_Array_Get_01( strtoupper($l_sTipo), $l_sFunzione );
        ksort( $l_aStati );
        foreach( $l_aStati as $codice => $item )
            {
            // Cerca l'indice tramite il contenuto (associativo) del 'nome'.
            //var_dump( $item );
            $l_iCodice = $item[ 'codice' ];      
            $l_sNome   = $item[ 'nome'   ];      
            //var_dump( $l_iCodice );
            if( $l_iCodice == $p_sCodice )
                {
                //echo "FOUND:" . $p_sCodice;
                return $item;
                //continue;
                }
            }; 
        
echo "NOT FOUND:" . $p_sCodice ;
return "Stato_GetNomeByCodice_01: " . $p_sCodice;
        
return "WIP";        
          
        // Return value.
        return $rv;
        
        }//Stato_GetNomeByCodice_01
         
        
    public function Query_Execute_01( $p_sQuery )
        {
        /*
        $query  = "";        
        $query .= "SELECT   * ";
        $query .= "FROM     luda_server_api_codici ";
        $query .= "WHERE    tipo     = '" . $p_sSubject  . "' ";
        $query .= "AND      funzione = '" . $p_sFunction . "' ";
        $query .= "ORDER BY nome ";
        $query .= "";
        */
        $query = $p_sQuery; 
        //echo "QE01=[" . $query . "]<BR>";
        $rv = $this->m_oDB->Query_01($query);
        
        return $rv;
        }//Query_Execute_01

    public function Query_Execute_02( $p_sQuery )
        {
        $query = $p_sQuery; 
        //echo "<br>Query_Execute_02 :: [" . $query . "]<BR>";
        $result = $this->m_oDB->Query_01($query);
        
        // Recordset in array.
        $dataArray = Array();
       
        $num_records  = $this->m_oDB->RecordCount_01();
        $columns_name = $this->m_oDB->ColumnsName_01();
        //var_dump( $columns_name );
        //exit();
        
        //echo "<br>Numero di records = <b>[" . $num_records . "]</b><br>";
    
        /* Select queries return a resultset */
        if ( ! is_null($result) ) 
            {
            //printf( "Il recordset contiene [%d] righe.\n", $num_records );
            //echo "<TABLE border='1' >";
            
            // Header.
            $line  = "";
            $line .= "<TR class='cl_table_header_columns_name' >";
            foreach( $columns_name as $col_num => $col_name )
                {
                $line .= "<TD >" .$col_name. "</TD>";
                }
            $line .= "</TR>";
            //echo $line;
          
            // Data.
            while( $obj = $this->m_oDB->Fetch_01() )
                {//wh_strt
                //var_dump( $obj );
                $line ="";
                $line.="<TR >";
                foreach( $columns_name as $col_num => $col_name )
                    {
                    $line .= "<TD >" . $obj->$col_name . "</TD>";
                    $item[ $col_name ] = $obj->$col_name;
                    }
                $line.="</TR>";
                //print_r( $item );
                $dataArray[] = $item;
                }//wh_stop
            
            }
            
        if( 1 ){}else
        {
        echo "<pre>";
        print_r( $dataArray );
        echo "</pre>";
        }

        return $dataArray;
        }//Query_Execute_02

        
        
        
        

    }//cLUDA_API
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// EoF :: "luda_class_api.PHP"
///////////////////////////////////////////////////////////////////
?> 