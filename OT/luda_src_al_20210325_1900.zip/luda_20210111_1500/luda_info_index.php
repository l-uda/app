<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Database_Index(); } </script>
<script>
</script>
</head>
   
<?php $oDB = new cLUDA_DB(); ?>
 
<?php $wwwpath = LUDA_WWW_Site_Path_Get_01(); ?>

<?php

//echo "<HR>";
$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
//echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//echo "<HR>";

//echo "<HR>";
$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
//echo "<HR>";

// Massimo codice (indipendentemente da SRV oppure UDA).
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
//echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
//echo "<HR>";

?>

<body>
     
<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>
  

<main role="main">
    
    <div class="container" >
        
        <H1 >Info &bull; Index</H1>
        <QQQHR />                                    
   
        <CENTER >
        <DIV QQQid='div_server_master_controls' >
        <TABLE border='0' cellpadding='10' cellspacing=0 QQQid='table_server_master_controls' style=' width:99%; ' >
     
      
            <TR>
                <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
                    <HR />
                    <?php
                    //echo "<HR>";
                    //$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
                    //echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
                    //echo "<HR>";
                    //echo "<HR>";
                    //$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
                    //echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
                    //echo "<HR>";
                    // Massimo codice (indipendentemente da SRV oppure UDA).
                    //$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
                    //echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
                    //echo "<HR>";
                    ?>
                  
                    
                    <CENTER >Info LUDA_20210128_1530_Inuggi_--architettura_UDA_012021.pdf</CENTER>
                    <IFRAME src='./info/LUDA_20210128_1530_Inuggi_--architettura_UDA_012021.pdf' style=' width:800px; height:600px; ' >---</IFRAME>
                    <BR />                  
                    <A href='./info/LUDA_20210128_1530_Inuggi_--architettura_UDA_012021.pdf' target='_blank' > Open in new window... </A>
                    <HR />                  
                    
                    <CENTER >Info LUDA_20201119_0940_Volta---architettura_UDA_112020_video.pdf</CENTER>
                    <!--
                    <IFRAME src='./info/LUDA_20201119_0940_Volta---architettura_UDA_112020_video.pdf' style=' width:800px; height:600px; ' >---</IFRAME>
                    !-->
                    <BR />                  
                    <A href='./info/LUDA_20201119_0940_Volta---architettura_UDA_112020_video.pdf' target='./info/LUDA_20201119_0940_Volta---architettura_UDA_112020_video.pdf' > Open in new window... </A>
                    <HR />                  
                  
                    <CENTER >Info LUDA_Bozza funzionamento_20200320_1700_Inuggi.pdf</CENTER>
                    <!--
                    <IFRAME src='./info/LUDA_Bozza funzionamento_20200320_1700_Inuggi.pdf' style=' width:800px; height:600px; ' >---</IFRAME>
                    !-->
                    <BR />                  
                    <A href='./info/LUDA_Bozza funzionamento_20200320_1700_Inuggi.pdf' target='./info/LUDA_20201119_0940_Volta---architettura_UDA_112020_video.pdf' > Open in new window... </A>
                    <HR />
                    
                    
                    </TD>
            </TR>
       
           
        </TABLE>
        </DIV>
        </CENTER>
     
    </div>
 
</main>

<footer>
</footer>

</BODY>
</HTML>