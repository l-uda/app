<?php

///////////////////////////////////////////////////////////////////

Class cLUDA_Temp
    {

    // Tipo della API (che effettua la richiesta REST): "SRV" oppure "UDA" .
    private $m_sSelfTipo = "";

    // Database object.
    private $m_oDB = NULL;

    function __construct( $p_sSelfTipo ) {
print "cLUDA_API :: constructor<br>\n";
  
global $g_server_db_address ;
global $g_server_db_user    ;
global $g_server_db_pass    ;
global $g_server_db_name    ;
 
//  if( 0 )      
//       $this->m_oDB = new mysqli("localhost", "root", "", "dbluda");
//  else
       //$this->m_oDB = new mysqli($g_server_db_address, $g_server_db_user, $g_server_db_pass, $g_server_db_name);
       $this->m_oDB = new cLUDA_DB();
       //$g_server_db_address, $g_server_db_user, $g_server_db_pass, $g_server_db_name);
         //              cLUDA_DB
  
    // Tipo della API.
    if( ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_SRV) && ($p_sSelfTipo!=LUDA_CONSTANT_SERVER_TIPO_UDA) )
        {
        echo "ATTENZIONE: il Tipo <b>[" .$p_sSelfTipo. "]</b> della API deve essere: 'SRV' oppure 'UDA' !!!";
        exit();
        return FALSE;
        }
    $this->m_sSelfTipo = $p_sSelfTipo;
  
    }//__construct

    function __destruct() 
        {
        $this->m_oDB->Finish_01();
        }//__destruct


    public function Get_01( $p_iI )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $stato = $this->_Get_SelfSrv_01($p_iI); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $stato = $this->_Get_SelfUda_01($p_iI); } 
        return $stato; 
        }//Get_01
    private function _Get_SelfSrv_01( $p_iI )
        {
        //->_API_Tipo_Get_01( $p_iI );         
        $query = "SELECT stato_by_uda FROM luda_server_stati WHERE iduda = $p_iI ";
echo "QUERY = [" . $query  . "]<br>";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $this->m_oDB->Result_01();
var_dump( $recordset );
$record = $this->m_oDB->Fetch_01();
var_dump( $record );
$stato = $record->stato_by_uda;
var_dump( $stato );
//exit();        
return $stato;
        }//_Get_SelfSrv_01  
    private function _Get_SelfUda_01( $p_iI )
        {
        //$this->_API_Tipo_Get_01( $p_iI );
        $query = "SELECT stato_by_srv FROM luda_server_stati WHERE iduda = $p_iI ";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $this->m_oDB->Result_01();
var_dump( $recordset );
$record = $this->m_oDB->Fetch_01();
var_dump( $record );
$stato = $record->stato_by_srv;
var_dump( $stato );
return $stato;
        }//_Get_SelfUda_01 
  
/*
qqq000    
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
$record = $oDB->Fetch_01();
var_dump( $record );
qqq111
*/    
  

    public function Put_01( $p_iI, $p_iK )
        {
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $this->_Put_SelfSrv_01($p_iI,$p_iK); }  
        if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $this->_Put_SelfUda_01($p_iI,$p_iK); }  
        }//Put_01
    private function _Put_SelfSrv_01( $p_iI, $p_iK )
        {         
        $query = "UPDATE luda_server_stati SET stato_by_srv = $p_iK WHERE iduda = $p_iI ";        
        $this->m_oDB->Query_01($query);
        }//_Put_SelfSrv_01
    private function _Put_SelfUda_01( $p_iI, $p_iK )
        { 
        $query = "UPDATE luda_server_stati SET stato_by_uda = $p_iK WHERE iduda = $p_iI ";        
        $this->m_oDB->Query_01($query);
        }//_Put_SelfUda_01 
















    }//cLUDA_Temp
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// EoF :: "luda_class_api.PHP"
///////////////////////////////////////////////////////////////////
?> 