<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Status_Index(); } </script>
<script>
</script>
</head>

 

<BODY>
  

<header>
<?php 
// Mostra il NavBar Menu SE in debug
if( isset($_GET['d']) ) { $prm_d = $_GET['d']; } else { $prm_d = ""; }
if( $prm_d == "TRUE" )
    {
    LUDA_HTML_HEADER_Navbar_Print();
    }
?>
</header>

<main role="main">

<div class="container" >

 

<?php $oDB = new cLUDA_DB(); ?>



<?php
// API Data to be sent (as 3rd parameter, if needed).
$par_app_data_send = LUDA_API_Parameters_GetFromREST( $_GET, 'cbo_app_data' );
$par_uda_data_send = LUDA_API_Parameters_GetFromREST( $_GET, 'cbo_uda_data' );
$par_srv_data_send = LUDA_API_Parameters_GetFromREST( $_GET, 'cbo_srv_data' );
//var_dump( $par_app_data_send );
//var_dump( $par_uda_data_send );
//var_dump( $par_srv_data_send );
$api_data = "";
$api_data = $par_app_data_send == "" ? $api_data : $par_app_data_send ;
//var_dump( $api_data );
$api_data = $par_uda_data_send == "" ? $api_data : $par_uda_data_send ;
//var_dump( $api_data );
$api_data = $par_srv_data_send == "" ? $api_data : $par_srv_data_send ;
//var_dump( $api_data );
//exit( );
?>
    
<?php


//echo "<HR>";
$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
//echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//echo "<HR>";

//echo "<HR>";
$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
//echo "<HR>";

// Massimo codice (indipendentemente da SRV oppure UDA).
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
//echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
//echo "<HR>";

?>

<?php

//$l_sImgUdaStati_url = 'img/CPIM_LUDA_API_Status_C3.png';
$l_sImgUdaStati_url = 'img/CPIM_LUDA_API_Status_C4.png';


//$l_sImgAPI_stati_url = "img/app_uda_managed_status_2021-02-25_A.jpg";
$l_sImgAPI_stati_url = "img/app_uda_managed_status_2021-03-01_B.jpg";

?>

    
<?php    
echo "<A href='" .$l_sImgAPI_stati_url. "' target='_blank' ><IMG src='" .$l_sImgAPI_stati_url. "' /></A>";
?>
    
<HR />
<!--
<A href='img/CPIM_LUDA_Status_20200201B.png' target='_blank' ><IMG src='img/CPIM_LUDA_Status_20200201B.png' /></A>
!-->


    
    
<?php


//define( "CONST_CPIM_LUDA_API_URL_ADDR_PREFIX_FOLDER" , "luda_20201201_0921" );
define( "CONST_CPIM_LUDA_API_URL_ADDR_PREFIX_FOLDER" , "luda_20210111_1500" );

if( 0 )
{}
else
{
//exit();
// DISABILITATO PER implementare la nuova versione delle API descritte nel PDF aggiornato da Alberto Inguggi.
}

 

$gAtypes = Array();
if( 1 ) { $gAtypes[] = "app"; }
if( 1 ) { $gAtypes[] = "uda"; }
if( 0 ) { $gAtypes[] = "srv"; }

$gAfunctions = Array();
//$gAfunctions[] = "get";
//$gAfunctions[] = "put";
$gAfunctions[] = "get";
$gAfunctions[] = "put";

$uda_number_num_max = 5;

$api_codes_qty_max = 22;

foreach( $gAtypes as $idx_type => $type )
    {//for_type_strt
    echo "<HR>";
    echo "<H1 style=' background-color:yellow; border:1px solid black; color:black; font-weight:bold; padding:9px; width:99%; ' >";
    echo "Soggetti: " .strtoupper($type) ;
    echo "</H1>";
    echo "<H2 style=' background-color:yellow; border:1px solid black; color:black; font-weight:bold; padding:9px; width:99%; ' >";
    echo "<FORM method='get' >";
    echo "Data to be sent: ";
    $cbo_id = "cbo_" . $type. "_data";
    if( 0 )
        {
        echo "<SELECT id='" .$cbo_id. "' name='" .$cbo_id. "' >";
            echo "<OPTION value='1' >1</OPTION>";
            echo "<OPTION value='2' >2</OPTION>";
            echo "<OPTION value='3' >3</OPTION>";
        echo "</SELECT>";
        }
    else
        {
        echo "<INPUT id='" .$cbo_id. "' name='" .$cbo_id. "' value='" .$par_app_data_send. "' >";
        }
    echo "<H4>";
    echo " (per aggiornare con nuovo valore: premere [Invio...])";
    echo "</H4>";
    echo "</FORM>";
    echo "</H2>";
    echo "<BR />";
        
    echo "<H3>Status</H3>";
    echo "<A href='" .$l_sImgUdaStati_url. "' target='_blank' ><IMG src='" .$l_sImgUdaStati_url. "' /></A>";
//    echo "<HR />";
    for( $uda_number = 1; $uda_number <= $uda_number_num_max; $uda_number++ )
        {//for_uda_strt
        foreach( $gAfunctions as $idx_function => $function )
            {//for_api_code_strt
            

if( 0 ) {}
else
{
//$l_aStati = Stati_Array_Get_01( $p_sSubject, $p_sFunction );
    
    

//$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_UDA;
//$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GET;

$l_sTipo     = strtoupper($type);
$l_sFunzione = strtoupper($function);

//echo $l_sTipo . "-". $l_sFunzione;
//exit();
$oAPI = new cLUDA_API( $l_sTipo ); 
//$l_aStati = $oAPI->Stati_Array_Get_01( strtoupper($l_sTipo), $function );
$l_aStati = $oAPI->Stati_Array_Get_02( strtoupper($l_sTipo), $l_sFunzione );
ksort( $l_aStati );
if( 1 ){}else
{
echo "<PRE >";
print_r( $l_aStati );
echo "</PRE>";
}
////echo "<PRE >";
//print_r( $l_aStati );
//echo "</PRE>";
//exit();
}



            echo "<H2>" . strtoupper($type). " n." .$uda_number. " - Function: " .strtoupper($function) . "</H1>";
//            for( $api_code = 0; $api_code <= $api_codes_qty_max; $api_code++ )
            for( $api_code = -1; $api_code <= $api_codes_qty_max; $api_code++ )
                {//for_function_strt
                
                // Controlla se e' un Codice/Stato associato "valido/esistente"
                if( array_key_exists( $api_code, $l_aStati ) )
                    {
                    //echo "YES";
                    }
                else
                    {
                    //echo "NOT";
                    continue;
                    }
                
                // get / put ("k" used or not)
                $url_data_str = "";
                if( $function=="get" ) 
                    { 
                    $url_k_str = "";                     
                    }
                else 
                    { 
                    $url_k_str = "&k=" . $api_code; 
                    if( $l_aStati[$api_code]['num_parametri'] == 3 )
                        {
                        // Terzo_parametro: data.
                        $url_data_str = "&data=" . $api_data;                     
                        }                    
                    }
                
                // Only one "get" URL (no "k" neeeded).
                if( ($function=="get") && ($api_code>0) ) 
                    {
                    continue; 
                    }
                    
// Get con parametro "-1".                    
$uda_number_str = $uda_number;
if( $api_code == -1 ) { $uda_number_str = $api_code; }
                    
                $url_api_name = "/api/" .$type. "/" .$function. "/?i=" . $uda_number_str . $url_k_str. $url_data_str;
                //$url_api_url  = "./luda/www/" .CONST_CPIM_LUDA_API_URL_ADDR_PREFIX_FOLDER. "/" . $url_api_name;
                //$url_api_url  = "./luda/www/" . CONST_CPIM_LUDA_API_URL_ADDR_PREFIX_FOLDER . "/" . $url_api_name;
                $url_api_url  = "./" . $url_api_name;
                
                $stato_codice = $l_aStati[ $api_code ][ 'codice' ];
                $stato_nome   = $l_aStati[ $api_code ][ 'nome'   ];
                
                echo "<A href='" .$url_api_url. "' style=' background-color:#44FF44; border:1px solid black; display:inline-block; padding:9px; width:300px; ' target='_blank' >";
                echo "API &bull; ";
                echo $l_sFunzione . " &bull; ";
                if( $l_sFunzione == LUDA_CONSTANT_SERVER_FUNZIONE_GET )
                    echo " ";
                else 
                    echo $stato_nome. " ";
                
                echo "</A> &gt; &quot;" .$url_api_name. "&quot;";
                echo "<BR>";
                }//for_function_stop
            }//for_api_code_stop
        echo "<BR>";
        }//for_uda_stop
        echo "<BR />";
    }//for_type_stop
  
?>

                    
   
<?php
/*
APP:
======
IDLE
GRP_SENT
REACHING_UDA
READY
RESUME 18
PAUSE
RESTART
DATA_SENT
COMPLETED
FINALIZED
===================================
 ( '' ,  0 , '' , 0 , 'IDLE'         , '' ,  );
 ( '' ,  2 , '' , 0 , 'GRP_SENT'     , '' ,  );
 ( '' ,  4 , '' , 0 , 'REACHING_UDA' , '' ,  );
 ( '' ,  5 , '' , 0 , 'READY'        , '' ,  );
 ( '' , 18 ,          'RESUME' 
 ( '' ,  8 , '' , 0 , 'PAUSE'        , '' ,  );
 ( '' , 12 , '' , 0 , 'RESTART'      , '' ,  );
 ( '' , 14 , '' , 0 , 'DATA_SENT'    , '' ,  ); 
 ( '' , 15 , '' , 0 , 'COMPLETED'    , '' ,  ); 
 ( '' , 17 , '' , 0 , 'FINALIZED'    , '' ,  );
*/
?>    
    
    

</div>
 
</main>

<footer>
</footer>
    
</BODY>
    
</HTML>