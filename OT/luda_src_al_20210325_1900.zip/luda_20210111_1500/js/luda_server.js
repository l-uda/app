///////////////////////////////////////////////////////////////////
// 
// BoF :: "luda_server.js"
// 
///////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////


// 
// Global variables.
//
var g_website_path_url = "";    // Absolute path of (this) website!
var g_audio_click_01   = null;  // AUdio object for sound "effects".
                                                                 

///////////////////////////////////////////////////////////////////
                                                                 

///////////////////////////////////////////////////////////////////
$( document ).ready(function() 
    {
    Body_General_Loaded( );
    Body_Loaded();
    });
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////

function Body_General_Loaded( )
    {
    }//Body_General_Loaded
///////////////////////////////////////////////////////////////////

function Body_Loaded_Index( )
    {
    g_audio_click_01 = new Audio();
    g_audio_click_01.src = 'img/click_004.mp3';
    
    setTimeout(function() {
        location.reload();
    }, 10000);
    
    }//Body_Loaded_Index
///////////////////////////////////////////////////////////////////

function Body_Loaded_Api_Index( )
    {
    }//Body_Loaded_Api_Index
///////////////////////////////////////////////////////////////////

function Body_Loaded_Api_Init( )
    {
    
    g_audio_click_01 = new Audio();
    g_audio_click_01.src = 'img/click_004.mp3';
   
    }//Body_Loaded_Api_Init
///////////////////////////////////////////////////////////////////
 
function Body_Loaded_Api_Status( )
    {
    setTimeout(function() {
        location.reload();
        }, 5000);
    }//Body_Loaded_Api_Status
///////////////////////////////////////////////////////////////////
 
function Body_Loaded_Database_Index( )
    {
    }//Body_Loaded_Database_Index
///////////////////////////////////////////////////////////////////
 
function Body_Loaded_Database_Table_List( )
    {
    }//Body_Loaded_Database_Table_List
///////////////////////////////////////////////////////////////////
 
function Body_Loaded_Layout_Index( )
    {
    console.log( "Body_Loaded_Layout_Index..." );
    }//Body_Loaded_Layout_Index
///////////////////////////////////////////////////////////////////

function Body_Loaded_Status_Index( )
    {
    }//Body_Loaded_Status_Index
///////////////////////////////////////////////////////////////////
 
function Body_Loaded_Update_Index( )
    {    
    }//Body_Loaded_Update_Index
///////////////////////////////////////////////////////////////////

function LUDA_Ajax_Execute_Encapsulated_01( p_url, p_tag )
    {
    
    $.ajax({
        url     : p_url, 
        success : function(result)
            {
            console.log(result);
            $( '#' + p_tag ).html(result);
            }
        });

    }//LUDA_Ajax_Execute_Encapsulated_01
///////////////////////////////////////////////////////////////////
 
function LUDA_Audio_Play_Click_01()
    {
    g_audio_click_01.play();
    }//LUDA_Audio_Play_Click_01
///////////////////////////////////////////////////////////////////
  
 
function LUDA_Esplorer_Pause( p_esplorer )
    {
    console.log( "Pausing Esplorer..." );
    
    LUDA_Audio_Play_Click_01();
    
    var url = "";
    url = "https://www.ansa.it/";
    url = "luda_uda_pause.php?i=" + p_esplorer;
    
    if( 0 )                                                 
    window.open( url );
    else
    LUDA_Ajax_Execute_Encapsulated_01( url, 'div_server_master_control_commands_result' );
    
    }//LUDA_Esplorer_Pause
///////////////////////////////////////////////////////////////////
 
function LUDA_Esplorer_Stop( p_esplorer )
    {
    console.log( "Stopping Esplorer..." );
    
    LUDA_Audio_Play_Click_01();
    
    var url = "";
    url = "https://www.ansa.it/";
    url = "luda_uda_stop.php?i=" + p_esplorer;
    
    if( 0 )                                                 
    window.open( url );
    else
    LUDA_Ajax_Execute_Encapsulated_01( url, 'div_server_master_control_commands_result' );
    
    }//LUDA_Esplorer_Stop
///////////////////////////////////////////////////////////////////
 
 
function LUDA_Game_Start( )
    {
    console.log( "Starting Game..." );
    
    LUDA_Audio_Play_Click_01();
    
    var url = "";
    url = "https://www.ansa.it/";
    url = "luda_game_start.php";
    
    if( 0 )                                                 
    window.open( url );
    else
    LUDA_Ajax_Execute_Encapsulated_01( url, 'div_server_master_control_commands_result' );
    
    }//LUDA_Game_Start
///////////////////////////////////////////////////////////////////
 
function LUDA_Game_Pause( )
    {
    console.log( "Pausing Game..." );
    
    LUDA_Audio_Play_Click_01();
    
    var url = "";
    url = "https://www.ansa.it/";
    url = "luda_game_pause.php";
    
    if( 0 )                                                 
    window.open( url );
    else
    LUDA_Ajax_Execute_Encapsulated_01( url, 'div_server_master_control_commands_result' );
    
    }//LUDA_Game_Pause
///////////////////////////////////////////////////////////////////
 
function LUDA_Game_Stop( )
    {
    console.log( "Stopping Game..." );
    
    LUDA_Audio_Play_Click_01();
    
    var url = "";
    url = "https://www.ansa.it/";
    url = "luda_game_stop.php";
    
    if( 0 )                                                 
    window.open( url );
    else
    LUDA_Ajax_Execute_Encapsulated_01( url, 'div_server_master_control_commands_result' );
    
    }//LUDA_Game_Stop
///////////////////////////////////////////////////////////////////

var g_sleep = -1; // 5000;
var g_timeoutID = null ;

function LUDA_Game_Map_Randomizer_01()
    {

//echo "var g_sURL_" .$pos_app. " = '" . $l_url_api_call . "';\n";
    
//alert( g_sURL_1 );
//alert( g_sURL_2 );
//alert( g_sURL_3 );
//alert( g_sURL_4 );
//alert( g_sURL_5 );

$.ajax({ url: g_sURL_1 }).done(function() { console.log( "OK INIT per: " + g_sURL_1 );});
$.ajax({ url: g_sURL_2 }).done(function() { console.log( "OK INIT per: " + g_sURL_2 );});
$.ajax({ url: g_sURL_3 }).done(function() { console.log( "OK INIT per: " + g_sURL_3 );});
$.ajax({ url: g_sURL_4 }).done(function() { console.log( "OK INIT per: " + g_sURL_4 );});
$.ajax({ url: g_sURL_5 }).done(function() { console.log( "OK INIT per: " + g_sURL_5 );});



 g_sleep = 1;
console.log( "SLEEP.I = " + g_sleep );        
    
 // var timeoutID = scope.setTimeout(function[, delay, arg1, arg2, ...]);
    g_timeoutID = window.setTimeout( LUDA_Game_Map_Randomizer_Change_01, g_sleep ); // [, delay, arg1, arg2, ...]);
    
 // LUDA_Game_Map_Randomizer_Change_01();
     
return;

var t_sleep = 5000;
console.log( "SLEEP = " + t_sleep );        

    var tm_strt = 0;
    //jQuery.now();
    //var tm_strt = jQuery.now();
    
    LUDA_Game_Map_Randomizer_Change_01();
    alert( jQuery.now() );
      
    //tm_strt = jQuery.now();
    while( t_sleep > 0 )
        {
        LUDA_Game_Map_Randomizer_Change_01();
        tm_strt = jQuery.now();
        while( jQuery.now() < tm_strt + t_sleep )
            {
            ;
            }
        t_sleep = t_sleep - 500;
        console.log( "SLEEP = " + t_sleep );        
        } 
    
    
    return;

    
    for( rander=1; rander<10; rander+=rander) 
        {
        for( ttt=0; ttt<t_sleep; ttt++ )
            {
            ;
            }
        LUDA_Game_Map_Randomizer_Change_01();
        t_sleep += t_sleep ;
console.log( "SLEEP = " + t_sleep );        
        }
        
    
    }//LUDA_Game_Map_Randomizer_01
///////////////////////////////////////////////////////////////////

function LUDA_Game_Map_Resetter_01()
    {
    console.log( "LUDA_Game_Map_Resetter_01::I" );
            
    //alert( g_sURL_reset_1 );
    //alert( g_sURL_reset_2 );
    //alert( g_sURL_reset_3 );
    //alert( g_sURL_reset_4 );
    //alert( g_sURL_reset_5 );
    $.ajax({ url: g_sURL_reset_1 }).done(function() { console.log( "OK INIT per: " + g_sURL_reset_1 );});
    $.ajax({ url: g_sURL_reset_2 }).done(function() { console.log( "OK INIT per: " + g_sURL_reset_2 );});
    $.ajax({ url: g_sURL_reset_3 }).done(function() { console.log( "OK INIT per: " + g_sURL_reset_3 );});
    $.ajax({ url: g_sURL_reset_4 }).done(function() { console.log( "OK INIT per: " + g_sURL_reset_4 );});
    $.ajax({ url: g_sURL_reset_5 }).done(function() { console.log( "OK INIT per: " + g_sURL_reset_5 );});


LUDA_Audio_Play_Click_01();
    for( nth=0; nth<25; nth++ )
        {//for_nth_stop    
        var id_tag = '#div_' + nth; 
        var bckcol = "white";   
        $( id_tag ).css('background-color', bckcol );
        $( id_tag ).html( "- - -<br>- - -" );
    }//for_nth_strt

//alert( "Resetted data for all APPs" );

    }//LUDA_Game_Map_Resetter_01
///////////////////////////////////////////////////////////////////

function LUDA_Game_Map_Randomizer_Change_01()
    {

if( g_sleep > 2000 ) { return; }    
     
// return;   

LUDA_Audio_Play_Click_01();
    
    var points = g_aColors; // [40, 100, 1, 5, 25, 10];
    points.sort( function(a,b) {return 0.5 - Math.random()} );

/*
    for( nth=0; nth<25; nth++ )
        {//for_nth_stop    
        var bckcol = points[ nth ];   
        $( id_tag ).css('background-color', bckcol );
        $( id_tag ).html( "- - -" );
        }//for_nth_strt
*/
    
    for( nth=0; nth<25; nth++ )
        {//for_nth_stop    
        var id_tag = '#div_' + nth; 
        var bckcol = points[ nth ];   
        $( id_tag ).css('background-color', bckcol );      
//$( id_tag ).html( (1 + ((parseInt( 100 * (nth/5) + 0.2) / 20)) % 5)  ) ;


if( g_sleep < 1000 )
    $( id_tag ).html( 1+ parseInt( nth + Math.random() * 24 ) % 5 ); // (1 + ((parseInt( 100 * (nth/5) + 0.2) / 20)) % 5) + (nth%5) ) ;
else
    $( id_tag ).html( (1+ (1+ ((nth+4)%5) + parseInt(nth/5)) % 5) ); // (1 + ((parseInt( 100 * (nth/5) + 0.2) / 20)) % 5) + (nth%5) ) ;

    }//for_nth_strt

//g_sleep += g_sleep;
g_sleep *= 2 ;
console.log( "SLEEP = " + g_sleep );  
    
g_timeoutID = window.setTimeout( LUDA_Game_Map_Randomizer_Change_01, g_sleep ); // [, delay, arg1, arg2, ...]);


/*
//echo " g_aColors.push('" .$bckcol. "');
var first = g_aColors[0];
var last = g_aColors[g_aColors.length - 1];
g_aColors.forEach( 
    function(item,index,array) 
        {                   
        console.log(item, index);      
*/  
    
    }//LUDA_Game_Map_Randomizer_Change_01
///////////////////////////////////////////////////////////////////

function LUDA_Game_Map_Randomization_GotoNextStep_01( )
    {

//    var l_sUrl = "./api/srv/cmd/api_srv_cmd_randomizer_step_avanza.php?path=./api/srv/cmd/";
    var l_sUrl = "./api/srv/cmd/api_srv_cmd_randomizer_step_avanza.php?path=../../../";
    //alert( l_sUrl );
    console.log( l_sUrl );

    $.ajax({ 
        url: l_sUrl 
        }).done(function() 
            { 
            console.log( "OK AVANZATO di uno Step!" );
            }
        );
 
    }//LUDA_Game_Map_Randomization_GotoNextStep_01
///////////////////////////////////////////////////////////////////

function LUDA_Button_Page_Go_01( p_url )
    {
    //alert( p_url );
    window.location.href=p_url;
    }//LUDA_Button_Page_Go_01
///////////////////////////////////////////////////////////////////

function LUDA_Button_Page_Open_01( p_url )
    {
    //alert( p_url );
    window.open(p_url);
    }//LUDA_Button_Page_Open_01
///////////////////////////////////////////////////////////////////

function LUDA_Button_Page_EncapsuleIn_01( p_url, p_tag )
    {
     
    $.ajax({
         url     : p_url, 
         success : function(result)
             {
             console.log(result);
             $( '#' + p_tag ).html(result);
             }
         });
   
    }//LUDA_Button_Page_EncapsuleIn_01
///////////////////////////////////////////////////////////////////
 
function Test( )
    {
    alert("TEST!");
    }
///////////////////////////////////////////////////////////////////
 
///////////////////////////////////////////////////////////////////
// EoF :: "luda_server.js"
///////////////////////////////////////////////////////////////////