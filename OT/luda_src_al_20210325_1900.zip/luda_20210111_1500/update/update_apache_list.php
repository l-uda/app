<?php

echo "<H1 >UPDATE: Apache &gt; List<H1>";
echo "<H3 > ( 2020-04-23 - 23:00 ) </H3>";
echo "<HR />\n";
 
 
echo "<PRE >";
$cmd = "DIR  C:\\Wamp64\\www\\luda\\  /S  ";
echo "COMMAND = <B>[" .$cmd. "]</B>\n";
echo "<BR />\n";
//$rv = system( $cmd, $rv_str );   
 
//ob_start();

//$rv = system( $cmd );
$rv = shell_exec( $cmd );

//echo strlen( $rv );
//print_r( $rv, TRUE );
//exit();
  
//$rv_str = ob_get_contents();

// $rv_str = str_replace ( mixed $search , mixed $replace , mixed $subject [, int &$count ] ) : mixed
$rv_str = $rv;
$rv_str = str_replace (  "<DIR>" , "<HR>" , $rv_str );
//$rv_str = strip_tags ( $rv_str ); 
//$rv_str = str_replace (  "<" , "-" , $rv_str );
//$rv_str = str_replace (  ">" , "-" , $rv_str );
//echo( htmlspecialchars($rv) );
echo( $rv_str );
echo "</PRE>";
            
?>                                  