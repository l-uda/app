<?php

echo "<H1 >UPDATE: DropBox -to- Apache<H1>";
echo "<H3 > ( 2020-04-11 - 18:00 )</H3>";
echo "<HR />\n";
 
//echo "<H2 ><A href='./' >Update Service Menu...</A></H2>";
//echo "<H2 ><A href='' >Refresh Update (Dropbox -to- Apache)...</A></H2>";

//echo "<BR />\n";



if( 0 )
{
$cmd = "COPY D:\\Temp\\TMP01.TXT  D:\\Temp\\TMP02.TXT";
echo "COMMAND = <B>[" .$cmd. "]</B>\n";
echo "<BR />\n";
$rv = system( $cmd );
var_dump( $rv );
}


               
if( 1 )
{
echo "<PRE >";
$cmd = "XCOPY C:\\Users\\Sax\\Data\\Shared\\dropbox_saxinfomus_gmailcom\\Dropbox\\LUDA\\Sources\\www\\luda\\*.*  C:\\Wamp64\\www\\luda\\  /S  /E  /Y  ";
echo "COMMAND = <B>[" .$cmd. "]</B>\n";
echo "<BR />\n";
$rv = system( $cmd );
var_dump( $rv );
echo "</PRE>";
}



if( 0 )
{
$cmd = "XCOPY C:\\Usr\\Sax\\Data\\_SHARED_\\dropbox_saxinfomus_gmailcom\\Dropbox\\LUDA\\Sources\\www\\luda\\update\\*.*  C:\\Wamp64\\www\\luda\\update\\ /S /E ";
echo "COMMAND = <B>[" .$cmd. "]</B>\n";
echo "<BR />\n";
$rv = system( $cmd );
var_dump( $rv );
}


               
?>                                  