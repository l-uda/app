<?php

//echo getcwd();

//chdir( ".." );

//echo getcwd();

//include( "./luda_update_index.php" );

header( "Location: ../luda_update_index.php" );

?>