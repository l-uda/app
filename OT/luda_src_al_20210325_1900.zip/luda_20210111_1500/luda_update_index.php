<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Update_Index(); } </script>
</head>

<body>

<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>

<main role="main">

<div class="container" >
<H1 >Update &bull; Index</H1>
<HR />

<!--
<A href='/luda/' > LUDA - HOME PAGE </A>
<BR />
!-->


<!--
<A href='./update/update_dropbox_to_apache.php' target='div_update_result' > DropBox &gt; Apache</A> (OK)!
<BR />

<A href='./update/update_apache_to_dropbox.php' target='div_update_result' > Apache &gt; DropBox</A> (NIY)!
<BR />
!-->



<?php
$url = "./update/update_dropbox_to_apache.php";         
echo LUDA_HTML_Link_Show_02( $url, "DropBox &gt; Apache : (OK)!"  , "div_update_container" );
echo "<BR>";
?>

<?php
$url = "./update/update_apache_list.php";         
echo LUDA_HTML_Link_Show_02( $url, "Apache &gt; List : (OK)!"     , "div_update_container" );
echo "<BR>";
?>

<?php
$url = "./update/update_apache_to_dropbox.php";         
echo LUDA_HTML_Link_Show_02( $url, "Apache &gt; DropBox : (NIY)!" , "div_update_container" );
echo "<BR>";
?>


<DIV id='div_update_container' style=' border:1px dotted yellow; background-color:#aaaaaa; height:100%; width:99%; ' >
<IFRAME id='div_update_result' name='div_update_result' src='' style=' border:1px dotted yellow; background-color:#aaaaaa; height:100%; width:99%; ' >...</IFRAME>
</DIV>

</div>
 
</main>

<footer>
</footer>
</BODY>
</HTML>