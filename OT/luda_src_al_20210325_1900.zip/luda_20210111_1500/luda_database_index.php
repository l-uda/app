<?php
///////////////////////////////////////////////////////////////////
// 
// BoF :: "luda_database_index.PHP"
// 
// 2021-02-12 :: 15:00
// 2020-04-04 :: 19:00
// 
///////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////

session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<HTML lang="it" xmlns="http://www.w3.org/1999/xhtml">
    
<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Database_Index(); } </script>
<script>
</script>
</head>
   
<?php $oDB = new cLUDA_DB(); ?>
 
<?php $wwwpath = LUDA_WWW_Site_Path_Get_01(); ?>

<?php

//echo "<HR>";
$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
//echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//echo "<HR>";

//echo "<HR>";
$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
//echo "<HR>";

// Massimo codice (indipendentemente da SRV oppure UDA).
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
//echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
//echo "<HR>";

?>

<BODY >
     
<header>
<?php //LUDA_HTML_HEADER_Navbar_Print(); ?>
<?php 
// NAVBAR
// (mostra il NavBar Menu SE in debug)
if( isset($_GET['d']) ) { $prm_d = $_GET['d']; } else { $prm_d = ""; }
if( $prm_d == "TRUE" )
    {
    LUDA_HTML_HEADER_Navbar_Print();
    }
?>     
</header>
  

<main role="main">
    
    <div class="container" >
        
        <H1 >DataBase &bull; Index</H1>
        <QQQHR />                                    
   
        <CENTER >
        <DIV QQQid='div_server_master_controls' >
        <TABLE border='0' cellpadding='10' cellspacing=0 QQQid='table_server_master_controls' style=' width:99%; ' >
     
      
            <TR>
                <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
                <HR>
                  <CENTER >DataBase Counters</CENTER>
                  <?php
                  
                  //echo "<HR>";
                  //$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
                  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
                  //echo "<HR>";
                  
                  //echo "<HR>";
                  //$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
                  echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
                  //echo "<HR>";
                  
                  // Massimo codice (indipendentemente da SRV oppure UDA).
                  //$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
                  echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
                  //echo "<HR>";
                  
                  ?>
                <hr></TD>
            </TR>
      
    
            <TR>
                <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
                  <CENTER >DataBase Tables</CENTER>
                </TD>
            </TR>
           
                  
            <TR>
                <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
                <?php            
    
                $oConfig = new cLUDA_Config( );
                $config_name = "LUDA_SERVER_MASTER_BUTTONS_LINK";
                $config_type = "ANCHOR";
                $config_type = "BUTTON";
                $link_type = $oConfig->Put_ByName_01( $config_name, $config_type ); 
                          
                $url = "luda_database_table_list.php?tablename=luda_server_stati_uda";         
                echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_stati_uda'..." );
                echo "<br>";
                $url = "luda_database_table_list.php?tablename=luda_server_stati_app";         
                echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_stati_app'..." );
                echo "<br>";
                //$url = "luda_database_table_list.php?tablename=luda_server_stati_OLD";         
                $url = "luda_database_table_list.php?tablename=luda_server_stati_srv";         
                //echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_stati_OLD'..." );
                echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_stati_srv'..." );
                echo "<br>";
                
                //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_api_codici";         
                $url = "luda_database_table_list.php?tablename=luda_server_api_codici";         
                echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_api_codici'..." );
                echo "<br>";
                
                //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_configs";         
                $url = "luda_database_table_list.php?tablename=luda_server_configs";         
                echo LUDA_HTML_Link_Show_02( $url, "table 'luda_server_configs'..." );
                echo "<br>";
    
                ?>  
                </TD>
            </TR>
            
            
<?php    
echo "<TR><TD colspan='100%' style=' background-color:white; ' >";
echo "<BR>";
echo "<CENTER >";
echo "<A href='index.php' >Continua!</A>";
echo "</CENTER>";
echo "<BR>";
echo "</YD></TR>";
?>
      
            
           
        </TABLE>
        </DIV>
        </CENTER>
     
    </div>
 
</main>

<footer>
</footer>

</BODY>
</HTML>



<?php
///////////////////////////////////////////////////////////////////
// EoF :: "luda_database_index.PHP"
///////////////////////////////////////////////////////////////////
?>