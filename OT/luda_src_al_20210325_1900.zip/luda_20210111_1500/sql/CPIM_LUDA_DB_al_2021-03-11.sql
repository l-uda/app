-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: 62.149.150.78
-- Generato il: Mar 11, 2021 alle 14:11
-- Versione del server: 5.0.92-50-log
-- Versione PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Sql203214_1`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `luda_server_api_codici`
--

DROP TABLE IF EXISTS `luda_server_api_codici`;
CREATE TABLE IF NOT EXISTS `luda_server_api_codici` (
  `tipo` varchar(3) NOT NULL,
  `codice` int(11) NOT NULL,
  `funzione` varchar(3) NOT NULL,
  `num_parametri` int(11) NOT NULL COMMENT 'Numero di parametri di questa API',
  `num_ritorni` int(11) NOT NULL default '-1' COMMENT 'Numero di valori di ritorno di questa API',
  `nome` varchar(16) NOT NULL COMMENT 'Nome (GET oppure PUT) di questa API.',
  `descrizione` varchar(256) NOT NULL,
  `note` text,
  PRIMARY KEY  (`tipo`,`codice`,`funzione`),
  UNIQUE KEY `tipo` (`tipo`,`codice`,`funzione`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tabella dei Codici+Tipo (=PK) per le API';

--
-- Dump dei dati per la tabella `luda_server_api_codici`
--

INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 0, 'GNP', 0, -1, 'IDLE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 1, 'GNP', 0, -1, 'WAIT_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 2, 'GNP', 0, -1, 'GROUP_SENT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 3, 'GNP', 0, -1, 'REACH_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 4, 'GNP', 0, -1, 'REACHING_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 5, 'GNP', 0, -1, 'READY', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 6, 'GNP', 0, -1, 'START', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 7, 'GNP', 0, -1, 'STARTED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 8, 'GNP', 0, -1, 'PAUSE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 9, 'GNP', 0, -1, 'PAUSED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 10, 'GNP', 0, -1, 'RESUME', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 11, 'GNP', 0, -1, 'ABORT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 12, 'GNP', 0, -1, 'ABORTED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 13, 'GNP', 0, -1, 'RESTART', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 14, 'GNP', 0, -1, 'WAIT_DATA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 15, 'GNP', 0, -1, 'DATA_SENT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 16, 'GNP', 0, -1, 'COMPLETED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 17, 'GNP', 0, -1, 'FINALIZE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 18, 'GNP', 0, -1, 'FINALIZED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 20, 'GNP', 0, -1, 'ERROR_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 21, 'GNP', 0, -1, 'ERROR_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('COD', 22, 'GNP', 0, -1, 'ERROR_SERVER', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 0, 'GET', 1, 1, 'IDLE', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 1, 'GET', 1, 1, 'WAIT_APP', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 2, 'PUT', 2, 0, 'GROUP_SENT', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 3, 'GET', 1, 2, 'REACH_UDA', '', 'returns(status,data)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 4, 'PUT', 2, 0, 'REACHING_UDA', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 5, 'GET', 1, 1, 'READY', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 6, 'NOP', -1, -1, 'START', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 7, 'GET', 1, 1, 'STARTED', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 8, 'PUT', 2, 0, 'PAUSE', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 9, 'GET', 1, 1, 'PAUSED', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 10, 'PUT', 2, 0, 'RESUME', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 11, 'PUT', 2, 0, 'ABORT', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 12, 'GET', 1, 1, 'ABORTED', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 13, 'PUT', 2, 0, 'RESTART', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 14, 'GET', 1, 1, 'WAIT_DATA', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 15, 'PUT', 3, 0, 'DATA_SENT', '', 'parameters(id,status,data)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 16, 'GET', 1, 1, 'COMPLETED', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 17, 'NOP', -1, -1, 'FINALIZE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 18, 'GET', 1, 1, 'FINALIZED', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 20, 'NOP', -1, -1, 'ERROR_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 21, 'NOP', -1, -1, 'ERROR_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', 22, 'NOP', -1, -1, 'ERROR_SERVER', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 0, 'GET', 1, 1, 'IDLE', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 1, 'GET', 1, 1, 'WAIT_APP', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 2, 'NOP', -1, -1, 'GROUP_SENT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 3, 'NOP', -1, -1, 'REACH_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 4, 'NOP', -1, -1, 'REACHING_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 5, 'GET', 1, 1, 'READY', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 6, 'GET', 1, 1, 'START', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 7, 'PUT', 2, 0, 'STARTED', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 8, 'GET', 1, 1, 'PAUSE', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 9, 'PUT', 2, 0, 'PAUSED', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 10, 'GET', 1, 1, 'RESUME', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 11, 'GET', 1, 1, 'ABORT', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 12, 'PUT', 2, 0, 'ABORTED', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 13, 'GET', 1, 1, 'RESTART', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 14, 'PUT', 2, 0, 'WAIT_DATA', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 15, 'GET', 1, 2, 'DATA_SENT', '', 'returns(status,data)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 16, 'PUT', 2, 0, 'COMPLETED', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 17, 'GET', 1, 1, 'FINALIZE', '', 'returns(status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 18, 'PUT', 2, 0, 'FINALIZED', '', 'parameters(id,status)');
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 20, 'NOP', -1, -1, 'ERROR_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 21, 'NOP', -1, -1, 'ERROR_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('UDA', 22, 'NOP', -1, -1, 'ERROR_SERVER', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 0, 'NOP', -1, -1, 'IDLE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 1, 'NOP', -1, -1, 'WAIT_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 2, 'NOP', -1, -1, 'GROUP_SENT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 3, 'NOP', -1, -1, 'REACH_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 4, 'NOP', -1, -1, 'REACHING_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 5, 'NOP', -1, -1, 'READY', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 6, 'NOP', -1, -1, 'START', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 7, 'NOP', -1, -1, 'STARTED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 8, 'NOP', -1, -1, 'PAUSE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 9, 'NOP', -1, -1, 'PAUSED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 10, 'NOP', -1, -1, 'RESUME', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 11, 'NOP', -1, -1, 'ABORT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 12, 'NOP', -1, -1, 'ABORTED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 13, 'NOP', -1, -1, 'RESTART', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 14, 'NOP', -1, -1, 'WAIT_DATA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 15, 'NOP', -1, -1, 'DATA_SENT', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 16, 'NOP', -1, -1, 'COMPLETED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 17, 'NOP', -1, -1, 'FINALIZE', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 18, 'NOP', -1, -1, 'FINALIZED', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 20, 'NOP', -1, -1, 'ERROR_UDA', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 21, 'NOP', -1, -1, 'ERROR_APP', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('SRV', 22, 'NOP', -1, -1, 'ERROR_SERVER', '', NULL);
INSERT INTO `luda_server_api_codici` (`tipo`, `codice`, `funzione`, `num_parametri`, `num_ritorni`, `nome`, `descrizione`, `note`) VALUES('APP', -1, 'GET', 1, 1, 'INIT', '', 'returns(status)');

-- --------------------------------------------------------

--
-- Struttura della tabella `luda_server_configs`
--

DROP TABLE IF EXISTS `luda_server_configs`;
CREATE TABLE IF NOT EXISTS `luda_server_configs` (
  `idconfig` int(11) NOT NULL auto_increment,
  `name` varchar(64) NOT NULL,
  `value` varchar(256) NOT NULL,
  `description` text,
  PRIMARY KEY  (`idconfig`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dump dei dati per la tabella `luda_server_configs`
--

INSERT INTO `luda_server_configs` (`idconfig`, `name`, `value`, `description`) VALUES(1, 'LUDA_SERVER_MASTER_BUTTONS_LINK', 'BUTTON', 'ANCHOR oppure BUTTON');

-- --------------------------------------------------------

--
-- Struttura della tabella `luda_server_stati_app`
--

DROP TABLE IF EXISTS `luda_server_stati_app`;
CREATE TABLE IF NOT EXISTS `luda_server_stati_app` (
  `idapp` int(11) NOT NULL,
  `codice` varchar(16) default '2BDEF',
  `descrizione` varchar(64) NOT NULL,
  `stato_by_srv` int(11) default '0',
  `stato_by_app` int(11) NOT NULL default '0',
  `data_by_app` varchar(100) NOT NULL default '',
  `completed_by_app` varchar(100) NOT NULL default '' COMMENT 'Identificatori (numerici) delle postazioni completate da questa App/Gruppo (separati da ",")',
  `note` text NOT NULL,
  PRIMARY KEY  (`idapp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `luda_server_stati_app`
--

INSERT INTO `luda_server_stati_app` (`idapp`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_app`, `data_by_app`, `completed_by_app`, `note`) VALUES(1, 'AP1', 'Software APP N.1', -1, 15, '1', '', 'Gestione del Software APP N.1');
INSERT INTO `luda_server_stati_app` (`idapp`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_app`, `data_by_app`, `completed_by_app`, `note`) VALUES(2, 'AP2', 'Software APP N.2', -1, 15, '2', '', 'Gestione del Software APP N.2');
INSERT INTO `luda_server_stati_app` (`idapp`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_app`, `data_by_app`, `completed_by_app`, `note`) VALUES(3, 'AP3', 'Software APP N.3', -1, 15, '3', '', 'Gestione del Software APP N.3');
INSERT INTO `luda_server_stati_app` (`idapp`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_app`, `data_by_app`, `completed_by_app`, `note`) VALUES(4, 'AP4', 'Software APP N.4', -1, 15, '4', '', 'Gestione del Software APP N.4');
INSERT INTO `luda_server_stati_app` (`idapp`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_app`, `data_by_app`, `completed_by_app`, `note`) VALUES(5, 'AP5', 'Software APP N.5', -1, 15, '5', '', 'Gestione del Software APP N.5');

-- --------------------------------------------------------

--
-- Struttura della tabella `luda_server_stati_srv`
--

DROP TABLE IF EXISTS `luda_server_stati_srv`;
CREATE TABLE IF NOT EXISTS `luda_server_stati_srv` (
  `idsrv` int(11) NOT NULL,
  `codice` varchar(16) default '2BDEF',
  `descrizione` varchar(64) NOT NULL,
  `stato_by_srv` int(11) default '0',
  `data_by_srv` varchar(100) NOT NULL default '',
  `stato_by_cod` int(11) NOT NULL default '0',
  `note` text NOT NULL,
  PRIMARY KEY  (`idsrv`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `luda_server_stati_srv`
--

INSERT INTO `luda_server_stati_srv` (`idsrv`, `codice`, `descrizione`, `stato_by_srv`, `data_by_srv`, `stato_by_cod`, `note`) VALUES(1, 'SRV1', 'Master SRV N.1', 9, '', -1, 'Gestione del Master SRV N.1');

-- --------------------------------------------------------

--
-- Struttura della tabella `luda_server_stati_uda`
--

DROP TABLE IF EXISTS `luda_server_stati_uda`;
CREATE TABLE IF NOT EXISTS `luda_server_stati_uda` (
  `iduda` int(11) NOT NULL,
  `codice` varchar(16) default '2BDEF',
  `descrizione` varchar(64) NOT NULL,
  `stato_by_srv` int(11) default '0',
  `stato_by_uda` int(11) NOT NULL default '0',
  `data_by_uda` varchar(100) NOT NULL default '',
  `note` text NOT NULL,
  PRIMARY KEY  (`iduda`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `luda_server_stati_uda`
--

INSERT INTO `luda_server_stati_uda` (`iduda`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_uda`, `data_by_uda`, `note`) VALUES(1, 'UD1', 'Settaggi UDA N.1', -1, 0, '', 'Gestione della UDA N.1');
INSERT INTO `luda_server_stati_uda` (`iduda`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_uda`, `data_by_uda`, `note`) VALUES(2, 'UD2', 'Settaggi UDA N.2', -1, 22, '', 'Gestione della UDA N.2');
INSERT INTO `luda_server_stati_uda` (`iduda`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_uda`, `data_by_uda`, `note`) VALUES(3, 'UD3', 'Settaggi UDA N.3', -1, 7, '', 'Gestione della UDA N.3');
INSERT INTO `luda_server_stati_uda` (`iduda`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_uda`, `data_by_uda`, `note`) VALUES(4, 'UD4', 'Settaggi UDA N.4', -1, 1, '', 'Gestione della UDA N.4');
INSERT INTO `luda_server_stati_uda` (`iduda`, `codice`, `descrizione`, `stato_by_srv`, `stato_by_uda`, `data_by_uda`, `note`) VALUES(5, 'UD5', 'Settaggi UDA N.5', -1, 14, '', 'Gestione della UDA N.5');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
