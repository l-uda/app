<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_api.php"         );

//if( 1 )
{   
//$par_iStatus = LUDA_API_Parameters_GetFromREST( $_GET, 'status' );
//$par_GET_status = $par_iStatus;

// API object.
//$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV; //  COD;
//$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GNP;
//$oAPI = new cLUDA_API( $l_sTipo );
    
// Commands.
//$status_code = $par_GET_status;
//$status_item = $oAPI->Stato_GetNomeByCodice_01( $status_code );
//$status_name = $status_item[ 'nome' ];
//switch( $status_name )
    {//sw_strt
    //case LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_IDLE :
    //case LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_WAIT_APP :
        // INIT
        // REBOOT
        
        //exit();
        
        require_once( "./api/srv/cmd/api_srv_cmd_simulation.php" );
        LUDA_API_SRV_CMD_Simulation_01();

//        $url = $wwwpath . "./api/srv/cmd/api_srv_cmd_simulation.php" . "?status=" . $status_code;
//        require_once( $url );
        //break;
    //default:
    //    echo "bisogna speciificiare il comando!";
    //    exit();
    //break;
    }//sw_stop



echo "<BR>";
echo "<BR>";
echo "<A href='luda_game_simulation.php?rnd=" .time(). "' >Ri-esegui (looppa)...</A>";
echo "<BR>";
echo "<BR>";


    
 
echo "<BR>";
echo "<BR>";
echo "<A href='index.php' >Continua!</A>";
echo "<BR>";
echo "<BR>";
exit();

    
}
//else
{     
/*

//echo "GAME::API::SRV::INIT";
//$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV;
//$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_PUT;
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_COD;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GNP;

$par_iStatus = LUDA_API_Parameters_GetFromREST( $_GET, 'status' );

$oAPI = new cLUDA_API( $l_sTipo );

echo "Initing... (for code: " . $par_iStatus . ")";
echo "<BR>";
 
$status_code = $par_iStatus;
$status_item = $oAPI->Stato_GetNomeByCodice_01( $status_code );
$status_name = $status_item[ 'nome' ];

echo "status_code: " . $status_code . "<BR>";
echo "status_name: " . $status_name . "<BR>";
  
echo "<BR>";
 
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_PUT;
$oAPI = new cLUDA_API( $l_sTipo );
$numSrv = 1;
$stato = $oAPI->Put_02( $numSrv, $status_code );

echo "<A href='index.php' >Continua!</A>";

exit();
*/
}//else


?>