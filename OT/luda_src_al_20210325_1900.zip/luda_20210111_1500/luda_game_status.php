<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
require_once( "./api/srv/cmd/api_srv_cmd_game_functions.php" );
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Api_Init(); } </script>
<script>
</script>
</head>

<body>


<header>
<?php 
// NAVBAR
// (mostra il NavBar Menu SE in debug)
if( isset($_GET['d']) ) { $prm_d = $_GET['d']; } else { $prm_d = ""; }
if( $prm_d == "TRUE" )
    {
    LUDA_HTML_HEADER_Navbar_Print();
    }
?>         
</header>

<?php $oDB = new cLUDA_DB(); ?>

<main role="main">
<div class="container" >

    <CENTER >                                      
    <H1 >LUDA &bull; GAME &bull; Status</H1>
    </CENTER>                                      
  
<?php    
echo "\n";   
for( $pos_app = 1; $pos_app <= $g_server_esploratori_qty; $pos_app++ )
    {//for_esploratore_strt    
    $l_iId = ( 0 + $pos_app ) % 5;
    //LUDA_API_APP_CMD_CompletedList_Add_02( $pos_app, $p_iIdUdaCompletata ); 
    $app_stato_by_app_code = 15;
    $app_data_by_app_id    = $l_iId;
//    $l_url_api_call = "./api/app/put/index.php?i=" .$pos_app. "&k=" .$app_stato_by_app_code. "&data=" .$app_data_by_app_id ;
    //$l_url_api_call = "./api/app/put/index.php";
    $l_url_api_reset = "./api/app/put/index.php?i=" .$pos_app. "&k=" .$app_stato_by_app_code. "&data=" . "0";
    $l_url_api_call  = "./api/app/put/index.php?i=" .$pos_app. "&k=" .$app_stato_by_app_code. "&data=" .$pos_app ;
    //?i=" .$pos_app. "&k=" .$app_stato_by_app_code. "&data=" .$app_data_by_app_id ;
    //echo "URL = [" .$l_url_api_call. "]<BR>";
    //echo "<br>\n";   
    echo "<SCRIPT >";
    echo " var g_sURL_reset_" .$pos_app. " = '" . $l_url_api_reset . "'; ";
    echo " var g_sURL_" .$pos_app. " = '" . $l_url_api_call . "'; ";
    echo "</SCRIPT>";
    echo "\n";   
    //echo "\n<br>\n";   
    //echo "<br>";    
//require_once( $l_url_api_call );    
    }//
?>
     
     

    <CENTER >
    <DIV id='div_server_master_controls' >
    <TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >
    
        <TR style=' background-color:yellow; ' >
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
                <CENTER >
                    
                    <?php
                    $l_iCurrentStepOfGames   = LUDA_API_SRV_CMD_Game_Randomization_StepCurrent_Get_01();
                    $l_iStepsOfGamesQuantity = LUDA_API_SRV_CMD_Game_Randomization_StepQuantity_Get_01();
                    echo "Ci sono " .$l_iStepsOfGamesQuantity. " Steps in tutto.";
                    echo "<BR>";
                    if( $l_iCurrentStepOfGames > 0 )
                        {
                        echo "Lo Step corrente e' il n." .$l_iCurrentStepOfGames. "";
                        }
                    else
                        {
                        echo "Nessun Game in corso.";
                        }
                    ?>
                </CENTER>
            </TD>
        </TR>
        
        <?php 
        $nth = 0;                                                                
        for( $pos_uda = 0; $pos_uda <= $g_server_esploratori_qty; $pos_uda++ )
            {//for_esploratore_strt
            if( $pos_uda == 0 )
                {
                $bckcol = "orange";
                }
            else
                {
                $bckcol = "";
                }
            echo "<TR style=' background-color:" .$bckcol. "; ' >\n";
                for( $pos_esp = 0; $pos_esp <= $g_server_esploratori_qty; $pos_esp++ )
                    {//for_esploratore_strt
                    $bckcol = "";
                    if( $pos_uda == 0 )
                        {//riga_prima_strt
                        $line_str = $pos_esp ;
                        if( $pos_esp > 0 )
                            {
                            $line_str = "Step. n." . $pos_esp ;
                            }
                        else
                            {
                            $line_str = "/";
                            }
                        //$bckcol = "orange";
                        }//riga_prima_stop
                    else
                        {//righe_dati_strt
                        //$bckcol = "";
                            if( $pos_esp == 0 )
                                {
                                $bckcol = "orange";
                                //$line_str = "Postazione n." . $pos_uda ;
                                $line_str = "Gruppo n." . $pos_uda ;
                                }
                            else
                                {
                                $bckcol = "";
                                $line_str = $pos_uda . " / " . $pos_esp;
                                $id_tag = "div_" . $nth;

                                $id_tag_str = $id_tag;
                                $id_tag_str = "";
                                $id_tag_str = $id_tag;
                                
                                $assigned_str = LUDA_API_SRV_CMD_Game_Randomization_PositionOfApp_ByStep_Get_01( $pos_uda , $pos_esp );

                                $line_str  = "";
                                $line_str .= "<DIV id='" .$id_tag. "' style=' font-size:12px; height:100px; width:100px; ' >";
                                //$line_str .=  $id_tag_str;
                                //$line_str .=  "<BR>";
                                $line_str .=  "<SPAN style=' font-size:8px; ' >";
                                $line_str .=  "Gr.N." . $pos_uda;
                                $line_str .=  "<BR>";
                                $line_str .=  "Pos.N." . $pos_esp;
                                $line_str .=  "</SPAN>";
                                $line_str .=  "<BR>";
                                $line_str .=  "<BR>";
                                $line_str .=  "Assegnaz.N." . $assigned_str;
                                $line_str .=  "</DIV>";
                                $nth++;

                                if( $pos_esp == $l_iCurrentStepOfGames )
                                    { $bckcol = "yellow"; }

                                }
                        }//righe_dati_stop
                        //$bckcol = "white";
                        echo "<TD style=' background-color:" .$bckcol. "; color:black; font-size:30px; font-weight:bold; text-align:center; ' >";
                            echo $line_str;
                        echo "</TD>\n";
                    }//for_esploratore_stop
            echo "</TR>\n";  
            }//for_esploratore_stop
        ?>
        
        <?php
        if( $prm_d == "TRUE" )
            {
            $display_str = "";
            }
        else
            {
            $display_str = " display:none; ";
            }
        ?>
        
        <TR style=' background-color:yellow; <?php echo $display_str; ?> ' >
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
            <CENTER >
                <BUTTON onclick='LUDA_Game_Map_Resetter_01();'                   style=' background-color:#80ffff; ' >Resetta!</BUTTON>
                <BR />
                <BUTTON onclick='LUDA_Game_Map_Randomizer_01();'                 style=' background-color:#80ffff; ' >Randomizza!</BUTTON>
                <BR />
                <BUTTON onclick='LUDA_Game_Map_Randomization_GotoNextStep_01();' style=' background-color:#80ffff; ' >Avanzare di uno Step!</BUTTON>
                <BR />
                <!--
                <A href='img/LUDA_server_map_grab_02.png' target='_blank' ><IMG src='img/LUDA_server_map_grab_02.png' ></A>
                !-->
            </CENTER>
            </TD>
        </TR>

<?php    
echo "<TR><TD colspan='100%' style=' background-color:white; ' >";
echo "<BR>";
echo "<A href='index.php' >Continua!</A>";
echo "<BR>";
echo "</YD></TR>";
?>
        
        
    </TABLE></DIV>
    </CENTER>

</div> 
</main>

<footer>
</footer>


<script type="text/javascript" >

var g_aColors = ["#000000"];

console.log( g_aColors.length );

<?php

for( $rnd_col = 0; $rnd_col<25; $rnd_col++ )
    {//for_col_strt
    $col_hex = $rnd_col * 10 ; 
    $bckcol = sprintf( "#%02x%02x%02x", $col_hex,$col_hex,$col_hex );
    echo " g_aColors.push('" .$bckcol. "'); \n";
    }//for_col_stop
            
        
//  $("p#44.test").css("background-color","yellow");

/*
for( $nth = 0; $nth<25; $nth++ )
    {//for_col_strt
    $id_tag = "div_" . $nth;
    $col_hex = $nth * 10 ; 
    $bckcol = sprintf( "#%02x%02x%02x", $col_hex,$col_hex,$col_hex );
    echo " $('#" .$id_tag. "' ).css('background-color','" .$bckcol. "' );\n"; 
    //echo " g_aColors.push('" .$bckcol. "'); \n";
    //echo " $('#" .$id_tag. "' ).html('fade','" .$bckcol. "' );\n"; 
    }//for_col_stop
*/

?>

var first = g_aColors[0];
var last = g_aColors[g_aColors.length - 1];

g_aColors.forEach( 
    function(item,index,array) 
        {                   
        console.log(item, index);
        } );
        

</script>

</BODY>
</HTML>