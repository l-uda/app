<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : "";
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Index(); } </script>
<script>
</script>
</head>


<?php
// Mostra il NavBar Menu SE in debug
//if( isset($_GET['json']) ) $message .= serialize($_GET['json'];
if( isset($_GET['u']) ) { $prm_u = $_GET['u']; } else { $prm_u = ""; }
if( isset($_GET['p']) ) { $prm_p = $_GET['p']; } else { $prm_p = ""; }
if( isset($_GET['d']) ) { $prm_d = $_GET['d']; } else { $prm_d = ""; }

$prm_u = trim($prm_u);
$prm_p = trim($prm_p);
$prm_d = trim($prm_d);

$message .= "GET"  . "<BR>". print_r( $_GET  , TRUE ) . "<BR>"; 
$message .= "POST" . "<BR>". print_r( $_POST , TRUE ) . "<BR>"; 
 
?>
<body>
  

<header>
<?php
// Mostra il NavBar Menu SE in debug
if( $prm_d == "TRUE" )
    {
    $g_bDebug = true;
    LUDA_HTML_HEADER_Navbar_Print();
    }
?>
</header>

<?php $wwwpath = LUDA_WWW_Site_Path_Get_01(); ?>

<main role="main">

<div class="container" >

<!--
<a href='https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-35448/zapsplat_multimedia_button_press_plastic_click_004_36871.mp3?_=4' >down...</a>    
!-->    
    
    <CENTER >
    <DIV id='div_server_master_controls' >
    <TABLE border='0' cellpadding='10' cellspacing=0 id='table_server_master_controls' >
    
        <TR>
        <TD colspan='100%' >
        <CENTER >
        <?php
        $url = $wwwpath . "index.php";
        //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >LUDA</a>";
        //echo LUDA_HTML_Link_Show_02( $url, "LUDA", '_blank' );
        echo LUDA_HTML_Link_Show_02( $url, "LUDA" , '' );
        ?>
      </CENTER>
        </TD>
        
<!--
            <TD colspan='7' style=' font-size:20px; font-weight:bold; text-align:center; ' >             
                <table style='border:1px dotted red; margin:0px; padding:0px; width:100%; ' >
                    <tr>
                        <td colspan='100%' >
                            <CENTER ><a href='index.php' ><H1 >LUDA</H1></a></CENTER>
                        </td>
                        <td target='div_update_result' style=' WWWwidth:100px; ' ><a href='luda_status_index.php' >=</a></td>
                    </tr>
                </table>            
            </TD>
!-->
        </TR>
     
    
        <TR>
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
              <CENTER >Comandi Generali</CENTER>
            <qqqhr></TD>
        </TR>
       
<?php
// 2021-02-25
if( 1 )
echo "        
        <TR style=' border-bottom:1px solid red; ' >
            <TD colspan='1' ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Game_Start ();' ><IMG src='img/LUDA_server_master_command_play_01.png'        /></BUTTON></CENTER></TD>
            <TD colspan='1' >&nbsp;</TD>
            <TD colspan='1' ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Game_Stop  ();' ><IMG src='img/LUDA_server_master_command_stop_01.png'        /></BUTTON></CENTER></TD>
            <TD colspan='1' >&nbsp;</TD>
            <TD colspan='1' ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Game_Pause ();' ><IMG src='img/LUDA_server_master_command_pause_01.png'       /></BUTTON></CENTER></TD>
            <TD colspan='1' >&nbsp;</TD>
            <TD colspan='1' ><CENTER ><BUTTON class='cl_button_server_master_command'                               ><IMG src='img/LUDA_server_master_command_portale_not_01.png' /></BUTTON></CENTER></TD>
        </TR>

";        
?>        
        
        <?php
        // Command buttons.
// 2021-02-25
if( 1 )        
        for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
            {//for_esploratore_strt
            //echo "<TR>";
            //    echo "<TD colspan='100%' ><CENTER ><HR >UDA " .$esploratore. "</CENTER></TD>";
            //echo "</TR>";
             
            {//original_copied_pasted_da_luda_api_statur_strt
            $uda_stato_by_srv     = LUDA_UDA_Status_BySrv_Get( $esploratore );
            $uda_stato_by_uda     = LUDA_UDA_Status_ByUda_Get( $esploratore );
            $uda_statusname_bysrv = LUDA_API_Command_Get_NameByCode( LUDA_CONSTANT_SERVER_TIPO_SRV, LUDA_CONSTANT_SERVER_FUNZIONE_PUT, $uda_stato_by_srv );
            $uda_statusname_byuda = LUDA_API_Command_Get_NameByCode( LUDA_CONSTANT_SERVER_TIPO_UDA, LUDA_CONSTANT_SERVER_FUNZIONE_PUT, $uda_stato_by_uda );
            }//original_copied_pasted_da_luda_api_status_stop
            //echo "[" . $uda_stato_by_srv . "][" . $uda_stato_by_uda ."]<HR>";
            switch( $uda_statusname_byuda )    
                {//sw_strt
                // Command: Play

                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_IDLE          :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_ABORTED       :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_PAUSED        :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_RESUMED       :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_COMPLETED     :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_FINALIZED     :
                case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_FINISHED      :
 
                //$cl_visibility_play  = "cl_visibility_visible";
                //$cl_visibility_pause = "cl_visibility_hidden";
                $cl_display_play  = "cl_display_block" ;
                $cl_display_pause = "cl_display_none"  ;
                break;
            case LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_STARTED       :
            default:
                // Command: Pause
                //$cl_visibility_play  = "cl_visibility_hidden";
                //$cl_visibility_pause = "cl_visibility_visible";
                $cl_display_play  = "cl_display_none" ;
                $cl_display_pause = "cl_display_block"  ;
                break;
                }//sw_stop
            echo "<TR style=' border-bottom:1px solid red; ' >";
                echo "<TD colspan='2' class=''                      ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Esplorer_Stop($esploratore);'  ><IMG src='img/LUDA_server_master_command_stop_01.png'  /></BUTTON></CENTER></TD>";
                echo "<TD colspan='3' class=''                      ><CENTER >UDA " .$esploratore. "</CENTER></TD>";
                echo "<TD colspan='2' class='" . $cl_display_play  . "' ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Esplorer_Play($esploratore);'  ><IMG src='img/LUDA_server_master_command_play_01.png'  /></BUTTON></CENTER></TD>";
                echo "<TD colspan='2' class='" . $cl_display_pause . "' ><CENTER ><BUTTON class='cl_button_server_master_command' onclick='LUDA_Esplorer_Pause($esploratore);' ><IMG src='img/LUDA_server_master_command_pause_01.png' /></BUTTON></CENTER></TD>";
            echo "</TR>";    
            //echo "<TR>";
            //    echo "<TD colspan='4' >&nbsp;</TD>";
            //echo "</TR>";  
            }//for_esploratore_stop
        ?>



        <TR>
        <TD colspan='100%' >
        <CENTER >
      
            
            
            
<?php $oDB = new cLUDA_DB(); ?>

<?php 
    
$l_sTablename = "luda_server_stati_srv";
//$oDB->Table_Print_01( $l_sTablename );  

?>
            
            
            
            <?php
           // qqq000
             
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GET;

//print_r( $_GET );
//echo "<BR>";
 
$oAPI = new cLUDA_API( $l_sTipo );
$numSrv = 1;
$stato = $oAPI->Get_02( $numSrv ); 


echo "<H6><I>HERE</I>: ri-attivare tutte le icone con i Comandi Generali (vedi parti commentate nei sorgenti)...</H6>";
echo "<BR>";




//echo "STATO = <B >[" .$stato. "]</B>";
//echo "<BR>";




// API::UDA::GET

//qqq000
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_PUT;
$oAPI = new cLUDA_API( $l_sTipo );
$l_aStati = $oAPI->Stati_Array_Get_01( strtoupper($l_sTipo), $l_sFunzione );
ksort( $l_aStati );
$g_aStatiGet = $l_aStati;

if( 1 ){}else
{
echo "<PRE>";
print_r( $g_aStatiGet );
echo "</PRE>";
}
///qqq111
 
$stato_descr = $g_aStatiGet[$stato]['codice'] ."_" . $g_aStatiGet[$stato]['nome'];
    echo "<hr>";
    //var_dump( $stato_descr );
           
            //qqq111
            ?>
             <?php
        $l_iCode      = $g_aStatiGet[$stato][ 'codice' ];
        $l_sCodeDescr = $g_aStatiGet[$stato][ 'nome'   ];
        //$url = $wwwpath . "index.php";
        //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >LUDA</a>";
        //echo LUDA_HTML_Link_Show_02( $url, "LUDA", '_blank' );
        //echo LUDA_HTML_Link_Show_02( $url, "LUDA" , '' );
        //echo "SERVER - STATUS: " . $l_sCodeDescr ." (" . $l_iCode .")";
        //echo "<BR>";
        ?>

        <?php
      
//qqq000
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_COD;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_GNP;
$oAPI = new cLUDA_API( $l_sTipo );
$l_aStati = $oAPI->Stati_Array_Get_01( strtoupper($l_sTipo), $l_sFunzione );
ksort( $l_aStati );
$g_aStatiGet = $l_aStati;
if( 1 ){}else
{
echo "<PRE>";
print_r( $g_aStatiGet );
echo "</PRE>";
//echo "exited257";
//exit(); 
} 
$stato_descr = $g_aStatiGet[$stato]['codice'] ."_" . $g_aStatiGet[$stato]['nome'];
//qqq11111
 
echo "<BR>";


        // Bottone REBOOT.        
        $status_name = LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_IDLE;
        $status_item = $oAPI->Stato_GetCodiceByNome_01( $status_name );
        $status_code = $status_item[ 'codice' ];
        $url = $wwwpath . "luda_game_init.php" . "?status=" . $status_code;
        echo LUDA_HTML_Link_Show_02( $url, "<b>[ADMIN] :: REBOOT</b><br>(dell'intera Installazione)..." , '' );
        echo "<BR>";
        echo "<BR>";


        // Bottone INIT.
        $status_name = LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_WAIT_APP;        
        $status_item = $oAPI->Stato_GetCodiceByNome_01( $status_name );
        $status_code = $status_item[ 'codice' ];
        if( 1 ){}else
        {
        echo "<PRE>";
        print_r( $status_code );
        echo "</PRE>";
        }        
        $url = $wwwpath . "luda_game_init.php" . "?status=" . $status_code;
        echo LUDA_HTML_Link_Show_02( $url, "<b>[ADMIN] :: INIT</b><br>(dell'intera Installazione)..." , '' );
        echo "<BR>";
        echo "<BR>";

        
        // Bottone Posizionamento delle APP all'interno della Gaming-Matrix.
        $url = $wwwpath . "luda_game_status.php" . "?rnd=" . time();
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEBUG] :: POSIZIONAMENTO ATTUALE</b><br>(dei Gruppi/Apps)..." , '' );
        echo "<BR>";
        echo "<BR>";

        // Bottone Posizionamento ALLO STEP SUCCESSIVO (delle APP all'interno della Gaming-Matrix).
        //$url = $wwwpath . "luda_game_status.php" . "?rnd=" . time();
        $url = $wwwpath . "./api/srv/cmd/api_srv_cmd_randomizer_step_avanza.php?path=../../../" . "&rnd=" . time();        
        //echo "<BR>URL = [" . $url . "]<BR>";
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEBUG] :: POSIZIONAMENTO SUCCESSIVO</b><br>(avanzamento di 1 Step per tutti i Gruppi/Apps)..." , '' );
        echo "<BR>";
        echo "<BR>";

        // Bottone RANDOMIZZA.  
        //if( $g_bDebug == true )
        {
        $url = $wwwpath . "luda_api_init.php" . "?rnd=" . time();
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEPRECATED] :: RANDOMIZZA</b><br>(i posizionamenti iniziali e seguenti)..." , '' );
        echo "<BR>";
        echo "<BR>";
        }
        
        
        
        
/*
        // Bottone REBOOT.        
        $status_name = LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_IDLE;
        $status_item = $oAPI->Stato_GetCodiceByNome_01( $status_name );
        $status_code = $status_item[ 'codice' ];
        $url = $wwwpath . "luda_game_init.php" . "?status=" . $status_code;
        echo LUDA_HTML_Link_Show_02( $url, "<b>REBOOT</b><br>(dell'intera Installazione)..." , '' );
        echo "<BR>";
        echo "<BR>";
*/

        
        // Bottone SIMULATION.
        //require_once( "./api/srv/cmd/api_srv_cmd_simulation.php" );
        $status_name = LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_IDLE;
        $status_item = $oAPI->Stato_GetCodiceByNome_01( $status_name );
        $status_code = $status_item[ 'codice' ];
//        $url = $wwwpath . "luda_game_init.php" . "?status=" . $status_code;
//        $url = $wwwpath . "./api/srv/cmd/api_srv_cmd_simulation.php" . "?status=" . $status_code;
        $url = $wwwpath . "luda_game_simulation.php"; // . "?status=" . $status_code;
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEPRECATED] :: SCHEDULER</b><br>(simulazione del ciclo dell'intera Installazione)..." , '' );
        echo "<BR>";
        echo "<BR>";

        
        // Bottone SCHEDULER.
        $url = $wwwpath . "luda_game_scheduler.php";
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEPRECATED] :: SCHEDULER</b><br>(dell'intera Installazione)..." , '' );
        echo "<BR>";
        echo "<BR>";
        ?>
 
        <?php
        // Bottone DATABASE.
        $url = $wwwpath . "luda_database_index.php";
        echo LUDA_HTML_Link_Show_02( $url, "<b>[DEBUG] :: DATABASE</b><br>(tabelle MySQL)..." , '' );
        echo "<BR>";
        echo "<BR>";
        ?>            
            
            
            
            
        <DIV id='div_server_master_control_status' >...</DIV>
        </CENTER>
        </TD>
        </TR>



    </TABLE></DIV>
    
    <DIV id='div_server_master_control_commands_result' >- - -</DIV>
    
<?php require_once( "./api/srv/cmd/api_srv_cmd_game_functions.php" ); ?>
<?php require_once( "./api/srv/cmd/api_srv_cmd_status.php"         ); ?> 
    
    <DIV class='cl_div_status_object' id='div_status_object_srvs' >
        <H1>Server Status</H1>    
        <?php LUDA_API_SRV_CMD_Status_01( ); ?> 
        <?php
        $l_iCurrentStepOfGames   = LUDA_API_SRV_CMD_Game_Randomization_StepCurrent_Get_01();
        $l_iStepsOfGamesQuantity = LUDA_API_SRV_CMD_Game_Randomization_StepQuantity_Get_01();
        //echo "Ci sono " .$l_iStepsOfGamesQuantity. " Games in tutto.";
        //echo "<BR>";
        if( $l_iCurrentStepOfGames > 0 )
            {
            echo "<SPAN style=' border:1px solid black; ' >Lo step corrente e' il n.<B>" .$l_iCurrentStepOfGames. "</B> su n.<B>" .$l_iStepsOfGamesQuantity. "</B> totali.</SPAN>";
            }
        else
            {
            //echo "Nessun Game in corso.";
            }
        ?>
    </DIV>
    
    <DIV class='cl_div_status_object' id='div_status_object_apps' >
        <H1>APPs Status</H1>    
        <?php LUDA_API_APP_CMD_Status_01( ); ?>  
    </DIV>

        
        
    <DIV class='cl_div_status_object' id='div_status_object_matrix' >
        <H1>APPs Completions</H1> 
<?php      
require_once( "./api/app/cmd/api_app_cmd_completedlist_get.php" );
?>
<?php


echo "<TABLE border='2'>";
 for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
            {//for_esploratore_strt
            //
            //
//$item = LUDA_API_GET_Minus_one_01();
$item = LUDA_API_APP_CMD_CompletedList_Get_01( $esploratore );
//var_dump( $item );
     $app_status_completed =       $item['completed_by_app'];
//$app_completed_list_str = "1,2,3,147";   
$app_completed_list_str = $app_status_completed;   
            
            echo "<TR >";
                echo "<TD colspan='100%' >";
                echo "L'APP n." .$esploratore. " ha completato le seguenti UDA n.: [<B>" .$app_completed_list_str. "</B>]</LI>";
                echo "</UL>";
                echo "</TD>";
            echo "</TR>";
            }//for_esploratore_strt
            echo "</TABLE>";
?>                
    </DIV>
    
    
    
    <DIV class='cl_div_status_object' id='div_status_object_udas' >
        <H1>UDAs Status</H1>    
        <?php LUDA_API_UDA_CMD_Status_01( ); ?>    
    </DIV>
    
    
   
    
    
    </CENTER>
 
</div>
 
</main>

<footer>
</footer>
</BODY>
</HTML>