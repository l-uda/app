<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_config.php"      );
require_once( "./luda_class_api.php"         );
//isset($_GET['status']) ? header( "Location: luda_status_index.php" ) : ""; 
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="it" xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php LUDA_HTML_HEAD_Metas_Print   (); ?>
<?php LUDA_HTML_HEAD_Styles_Print  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Init  (); ?>
<?php LUDA_HTML_HEAD_Scripts_Print (); ?>
<script type="text/javascript" > function Body_Loaded() { Body_Loaded_Api_Status(); } </script>
<script>
</script>
</head>

<body>


<header>
<?php LUDA_HTML_HEADER_Navbar_Print(); ?>
</header>

<main role="main">

<div class="container" >

<?php
                                                          
echo "<H1 >LUDA &bull; API &bull; STATUS</H1>\n";
//echo "<H2 >(2020-04-20 :: 09:00)</H1>\n";
echo "<HR />";                                      
//echo "<A href='update' >Update Service...</A>";
//echo "<BR />\n";
?>

<?php $oDB = new cLUDA_DB(); ?>


    <?php                                                        
    //echo "<HR />";
    //echo "<A href='/luda/' >Home!</A>";
    //echo "<BR />\n";
    ?>
    
    
    <?php
    //$oDB->Table_Print_01( "luda__server__stati" );
    //echo "<BR>";
    ?>
     

    <CENTER >
    <DIV id='div_server_master_controls' >
    <TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >
    
        <TR style=' background-color:yellow; ' >
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >UDA &bull; Stati</CENTER></TD>
        </TR>
        <TR style=' background-color:orange; ' >
            <TD colspan='1' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >UDA n.</CENTER></TD>
            <TD colspan='2' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Status.BySRV</CENTER></TD>
            <TD colspan='2' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Status.ByUDA</CENTER></TD>
        </TR>
     <?php
        for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
            {//for_esploratore_strt
            $uda_stato_by_srv     = LUDA_UDA_Status_BySrv_Get( $esploratore );
            $uda_stato_by_uda     = LUDA_UDA_Status_ByUda_Get( $esploratore );
            $uda_statusname_bysrv = LUDA_API_Command_Get_NameByCode( LUDA_CONSTANT_SERVER_TIPO_SRV, LUDA_CONSTANT_SERVER_FUNZIONE_PUT, $uda_stato_by_srv );
            $uda_statusname_byuda = LUDA_API_Command_Get_NameByCode( LUDA_CONSTANT_SERVER_TIPO_UDA, LUDA_CONSTANT_SERVER_FUNZIONE_PUT, $uda_stato_by_uda );
            echo "<TR>";
                echo "<TD style=' text-align:center; ' > UDA n. = [" . $esploratore          . "]</TD>";
                echo "<TD style=' text-align:right; '  > (Code.Name) = </TD>";
                echo "<TD style=' text-align:left;  '  > " . $uda_stato_by_srv . " - " . $uda_statusname_bysrv . " </TD>";
                echo "<TD style=' text-align:right; '  > (Code.Name) = </TD>";
                echo "<TD style=' text-align:left;  '  > " . $uda_stato_by_uda . " - " . $uda_statusname_byuda . " </TD>";
            echo "</TR>";  
            }//for_esploratore_stop
        ?>
    </TABLE></DIV>
    </CENTER>

</div> 
</main>

<footer>
</footer>

</BODY>
</HTML>

