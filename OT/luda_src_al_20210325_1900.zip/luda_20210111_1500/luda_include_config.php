<?php
///////////////////////////////////////////////////////////////////
// 
// BoF :: "luda_include_config.PHP"
// 
// 2021-03-01 :: 09:00
// 2020-12-01 :: 15:00
// 2020-04-04 :: 19:00
// 
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// 
// Constants.
//

define( "FOO", "something" );


define( "LUDA_CONSTANT_SERVER_ADDR"            , "/luda/"     );
define( "LUDA_CONSTANT_SERVER_API_URL"         , "/api/"      );
define( "LUDA_CONSTANT_SERVER_API_ADDR"        , "/luda/api/" );

define( "LUDA_CONSTANT_SERVER_API_URL_APP"     , "/app/"      );
define( "LUDA_CONSTANT_SERVER_API_URL_APP_GET" , "/app/get/"  );
define( "LUDA_CONSTANT_SERVER_API_URL_APP_PUT" , "/app/put/"  );

define( "LUDA_CONSTANT_SERVER_API_URL_SRV"     , "/srv/"      );
define( "LUDA_CONSTANT_SERVER_API_URL_SRV_GET" , "/srv/get/"  );
define( "LUDA_CONSTANT_SERVER_API_URL_SRV_PUT" , "/srv/put/"  );

define( "LUDA_CONSTANT_SERVER_API_URL_UDA"     , "/uda/"      );
define( "LUDA_CONSTANT_SERVER_API_URL_UDA_GET" , "/uda/get/"  );
define( "LUDA_CONSTANT_SERVER_API_URL_UDA_PUT" , "/uda/put/"  );

define( "LUDA_CONSTANT_SERVER_TIPO_COD"        , "COD"        );
define( "LUDA_CONSTANT_SERVER_TIPO_APP"        , "APP"        );
define( "LUDA_CONSTANT_SERVER_TIPO_SRV"        , "SRV"        );
define( "LUDA_CONSTANT_SERVER_TIPO_UDA"        , "UDA"        );

define( "LUDA_CONSTANT_SERVER_FUNZIONE_GNP"    , "GNP"        );
define( "LUDA_CONSTANT_SERVER_FUNZIONE_GET"    , "GET"        );
define( "LUDA_CONSTANT_SERVER_FUNZIONE_PUT"    , "PUT"        );



// Commands.


// API ALL's CODES
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_IDLE"          , "IDLE"         );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_WAIT_APP"      , "WAIT_APP"     );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_GROUP_SENT"    , "GROUP_SENT"   );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_REACH_UDA"     , "REACH_UDA"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_REACHING_UDA"  , "REACHING_UDA" );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_READY"         , "READY"        );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_START"         , "START"        );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_STARTED"       , "STARTED"      );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_PAUSE"         , "PAUSE"        );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_PAUSED"        , "PAUSED"       );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_RESUME"        , "RESUME"       );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_ABORT"         , "ABORT"        );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_ABORTED"       , "ABORTED"      );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_RESTART"       , "RESTART"      );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_WAIT_DATA"     , "WAIT_DATA"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_DATA_SENT"     , "DATA_SENT"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_COMPLETED"     , "COMPLETED"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_FINALIZE"      , "FINALIZE"     );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_FINALIZED"     , "FINALIZED"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_ERROR_UDA"     , "ERROR_UDA"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_ERROR_APP"     , "ERROR_APP"    );
define   ( "LUDA_CONSTANT_COMMAND_API_COD_GNP_NAME_ERROR_SERVER"  , "ERROR_SERVER" );


// API APP GET
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_IDLE"          , "IDLE"          );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_WAIT_APP"      , "WAIT_APP"      );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_REACH_UDA"     , "REACH_UDA"     );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_READY"         , "READY"         );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_STARTED"       , "STARTED"       );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_PAUSED"        , "PAUSED"        );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_ABORTED"       , "ABORTED"       );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_WAIT_DATA"     , "WAIT_DATA"     );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_COMPLETED"     , "COMPLETED"     );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_GET_NAME_FINALIZED"     , "FINALIZED"     );
// API APP PUT
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_GROUP_SENT"    , "GROUP_SENT"    );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_REACHING_UDA"  , "REACHING_UDA"  );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_PAUSE"         , "PAUSE"         );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_RESUME"        , "RESUME"        );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_ABORT"         , "ABORT"         );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_RESTART"       , "RESTART"       );
define   ( "LUDA_CONSTANT_COMMAND_API_APP_PUT_NAME_DATA_SENT"     , "DATA_SENT"     );


// API UDA GET
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_IDLE"          , "IDLE"          );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_WAIT_APP"      , "WAIT_APP"      );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_READY"         , "READY"         );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_START"         , "START"         );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_PAUSE"         , "PAUSE"         );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_RESUME"        , "RESUME"        );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_ABORT"         , "ABORT"         );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_RESTART"       , "RESTART"       );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_DATA_SENT"     , "DATA_SENT"     );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_GET_NAME_FINALIZE"      , "FINALIZE"      );
// API UDA PUT
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_STARTED"       , "STARTED"       );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_PAUSED"        , "PAUSED"        );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_ABORTED"       , "ABORTED"       );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_WAIT_DATA"     , "WAIT_DATA"     );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_COMPLETED"     , "COMPLETED"     );
define   ( "LUDA_CONSTANT_COMMAND_API_UDA_PUT_NAME_FINALIZED"     , "FINALIZED"     );


// API SRV
define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_IDLE"          , "IDLE"          );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_STARTED"       , "STARTED"       );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_ABORTED"       , "ABORTED"       );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_PAUSED"        , "PAUSED"        );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_RESUMED"       , "RESUMED"       );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_COMPLETED"     , "COMPLETED"     );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_FINALIZED"     , "FINALIZED"     );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_GET_NAME_FINISHED"      , "FINISHED"      );
////////
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_IDLE"          , "IDLE"          );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_START"         , "START"         );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_ABORT"         , "ABORT"         );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_PAUSE"         , "PAUSE"         );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_RESUME"        , "RESUME"        );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_FINALIZE"      , "FINALIZE"      );
//define   ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_FINISH"        , "FINISH"        );
//define ( "LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_COMPLETED"     , "COMPLETED"     );


///////////////////////////////////////////////////////////////////
// 
// Global variables.
//

$g_server_db_address = "localhost" ;
$g_server_db_user    = "root"      ;
$g_server_db_pass    = ""          ;
$g_server_db_name    = "dbluda"    ;
 

$g_server_esploratori_qty = 5;

$g_color_gui_background = "#FFDA95"; // 255>FF 218>DA 149>95



///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// EoF :: "luda_include_config.PHP"
///////////////////////////////////////////////////////////////////
?>