<?php



///////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////


//$g_server_esploratori_qty = 5;

//$g_color_gui_background = "#FFDA95"; // 255>FF 218>DA 149>95



///////////////////////////////////////////////////////////////////


function LUDA_API_Command_Get_CodeByName( $p_sTipo, $p_sFunzione, $p_sCommandName )
    {
    //echo "funzione LUDA_API_Command_Get_CodeByName :: I";
    //echo "<BR />\n";
    
    //echo "ATTENZIONE!!! NIY!!!";
    //echo "<BR />\n";
    
    //echo "p_sTipo = [" .$p_sTipo. "]<BR>\n";
    //echo "p_sFunzione = [" .$p_sFunzione. "]<BR>\n";
    //echo "p_sCommandName = [" .$p_sCommandName. "]<BR>\n";

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT codice AS command_codice ";
    $query .= "FROM   luda_server_api_codici   ";
    $query .= "WHERE  1 ";
    $query .= "AND    tipo     = '" . $p_sTipo        . "' ";
    $query .= "AND    funzione = '" . $p_sFunzione    . "' ";
    $query .= "AND    nome     = '" . $p_sCommandName . "' ";
    $result         = $loDB->Query_01($query);
    $num_records    = $loDB->RecordCount_01();
    $record         = $loDB->Fetch_01();
    $command_codice = $record->command_codice;  
    //echo "CommandCodice = [" .$command_codice. "]<BR>\n";

    // Return value.
    return $command_codice;
    
    }//LUDA_API_Command_Get_CodeByName
///////////////////////////////////////////////////////////////////

function LUDA_API_Command_Get_NameByCode( $p_sTipo, $p_sFunzione, $p_sCommandCode )
{
    //echo "funzione LUDA_API_Command_Get_NameByCode :: I";
    //echo "<BR />\n";
    
    //echo "ATTENZIONE!!! NIY!!!";
    //echo "<BR />\n";
    
    //echo "p_sTipo = [" .$p_sTipo. "]<BR>\n";
    //echo "p_sFunzione = [" .$p_sFunzione. "]<BR>\n";
    //echo "p_sCommandCode = [" .$p_sCommandCode. "]<BR>\n";

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT nome AS command_nome ";
    $query .= "FROM   luda_server_api_codici   ";
    $query .= "WHERE  1 ";
    $query .= "AND    tipo     = '" . $p_sTipo        . "' ";
    $query .= "AND    funzione = '" . $p_sFunzione    . "' ";
    $query .= "AND    codice   = '" . $p_sCommandCode . "' ";
    $result         = $loDB->Query_01($query);
    $num_records    = $loDB->RecordCount_01();
    $record         = $loDB->Fetch_01();
    $command_name   = $record->command_nome;  
    //echo "CommandName = [" .$command_name. "]<BR>\n";

    // Return value.
    return $command_name;
    
    }//LUDA_API_Command_Get_NameByCode
///////////////////////////////////////////////////////////////////

function LUDA_API_Parameters_GetFromREST( $array, $index )
    {
    $rv = isset($array[$index]) ? $array[$index] : 0;
    return $rv;
    }//LUDA_API_Parameters_GetFromREST
///////////////////////////////////////////////////////////////////

function LUDA_HTML_HEAD_Metas_Print( )
    {    
    echo '<meta charset="utf-8" >';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" >';
    }
///////////////////////////////////////////////////////////////////

function LUDA_HTML_HEAD_Scripts_Init( )
{
$url = LUDA_WWW_Site_Path_Get_01(); 
//echo "WEB_ROOT = [" .$url. "]<BR>\n";
     
//exit();
echo "<SCRIPT language='javascript' type='text/javascript' >";
echo "g_website_path_url = '" .$url. "';";
echo "</SCRIPT>";
}//LUDA_HTML_HEAD_Scripts_Init
///////////////////////////////////////////////////////////////////

function LUDA_HTML_HEAD_Scripts_Print( )
    {
    $wwwpath = LUDA_WWW_Site_Path_Get_01();
    
    $url = $wwwpath . "js/jquery-3.4.1.min.js";    
    echo "<script type='text/javascript' src='" .$url. "'></script>";
    
    $url = $wwwpath . "js/popper.min.js";    
    echo "<script type='text/javascript' src='" .$url. "'></script>";
    
    $url = $wwwpath . "js/bootstrap.min.js";    
    echo "<script type='text/javascript' src='" .$url. "'></script>";
    
    $url = $wwwpath . "js/luda_server.js";    
    echo "<script type='text/javascript' src='" .$url. "'></script>";
    }//LUDA_HTML_HEAD_Scripts_Print
///////////////////////////////////////////////////////////////////

function LUDA_HTML_HEAD_Styles_Print( )
    {
    $wwwpath = LUDA_WWW_Site_Path_Get_01();
    
    $url = $wwwpath . "css/bootstrap.min.css";
    echo "<link rel='stylesheet' type='text/css' href='" .$url. "' >";
    $url = $wwwpath . "css/luda_style.css";
    echo "<link rel='stylesheet' type='text/css' href='" .$url. "' >";
    }//LUDA_HTML_HEAD_Styles_Print
///////////////////////////////////////////////////////////////////

function LUDA_HTML_HEADER_Navbar_Print( )
    {
    
    $wwwpath = LUDA_WWW_Site_Path_Get_01();
    
    echo "<nav class='navbar navbar-expand-lg navbar-light bg-light'>";
    
    $url = $wwwpath . "index.php";
    echo "<A class='navbar-brand' QQQhref='" .$url. "' >";    
        $url = $wwwpath . "/img/CPIM_LUDA_LOGO_favicon_01.png";
        echo "<IMG src='" .$url."' style=' height:50px; wodth:50px; ' >";
    echo "</A>";
     //echo "<span class='divider cl_divider_verticale'>&nbsp;</span>";  
        
    
  echo '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">';
    
    $url = $wwwpath . "index.php";
    echo "<li class='nav-item active'>";
        //echo "<a class='nav-link' href='" .$url. "' >Home...</a>";
        echo LUDA_HTML_Link_Show_02( $url, "Home..." );
    echo "</li>";
   echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  

   
   

// UPDATE MENU.
if( 0 )
{//menu_update_strt
/*      
    $url = $wwwpath . "update";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >Update Service...</a>";
    echo "</li>";
*/
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle cl_cliccabile" QQQhref="#" id="navbarDropdownUpdate" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Update:                                 
        </a>';       
    echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownUpdate'>";
          $url = $wwwpath . "luda_update_index.php";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >Index...</a>";
        echo LUDA_HTML_Link_Show_02( $url, "Index..." );
        echo "<br>";
          $url = "./update/update_dropbox_to_apache.php";         
          echo LUDA_HTML_Link_Show_02( $url, "DropBox&nbsp;&gt;&nbsp;Apache..." , "div_update_container" );
          echo "<BR>";
          $url = "./update/update_apache_list.php";         
          echo LUDA_HTML_Link_Show_02( $url, "Apache&nbsp;&gt;&nbsp;List..."    , "div_update_container" );
          echo "<BR>";
          $url = "./update/update_apache_to_dropbox.php";         
          echo LUDA_HTML_Link_Show_02( $url, "Apache&nbsp;&gt;&nbsp;DropBox..." , "div_update_container" );
          echo "<BR>";

          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda__server__stati";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda__server__stati'...</a>";
          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_api_codici";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_api_codici'...</a>";
          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_configs";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_configs'...</a>";
    echo "</div>";
echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
   
   
/*      
    $url = $wwwpath . "update";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >Update Service...</a>";
    echo "</li>";
*/
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle cl_cliccabile" QQQhref="#" id="navbarDropdownUpdate" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Update:                                 
        </a>';       
    echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownUpdate'>";
          $url = $wwwpath . "luda_update_index.php";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >Index...</a>";
          echo LUDA_HTML_Link_Show_02( $url, "Index..." );
          echo "<br>";
$url = "./update/update_dropbox_to_apache.php";         
echo LUDA_HTML_Link_Show_02( $url, "DropBox&nbsp;&gt;&nbsp;Apache..." , "div_update_container" );
echo "<BR>";
$url = "./update/update_apache_list.php";         
echo LUDA_HTML_Link_Show_02( $url, "Apache&nbsp;&gt;&nbsp;List..."    , "div_update_container" );
echo "<BR>";
$url = "./update/update_apache_to_dropbox.php";         
echo LUDA_HTML_Link_Show_02( $url, "Apache&nbsp;&gt;&nbsp;DropBox..." , "div_update_container" );
echo "<BR>";
          
          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda__server__stati";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda__server__stati'...</a>";
          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_api_codici";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_api_codici'...</a>";
          //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_configs";
          //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_configs'...</a>";
    echo "</div>";
echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
  }//menu_update_stop     

 
  
  
  
  
  
      
/*        
    $url = $wwwpath . "luda_api_index.php";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >API Service...</a>";
    echo "</li>";
     
    $url = $wwwpath . "luda_api_status.php";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >API Status...</a>";
    echo "</li>";
*/
    
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle cl_cliccabile" QQQhref="" id="navbarDropdownApi" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          API:                                
        </a>';       
    echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownApi'>";
          $url = $wwwpath . "luda_api_index.php";
          echo LUDA_HTML_Link_Show_02( $url, "Index..." );
          echo "<br>";

          $url = "luda_api_codes.php";         
          echo LUDA_HTML_Link_Show_02( $url, "API&nbsp;&gt;&nbsp;Codes..." );
          echo "<BR>";

          $url = "luda_api_commands.php";         
          echo LUDA_HTML_Link_Show_02( $url, "API&nbsp;&gt;&nbsp;Commands..." );
          echo "<BR>";

          $url = "luda_api_status.php";         
          echo LUDA_HTML_Link_Show_02( $url, "API&nbsp;&gt;&nbsp;Status..." );
          echo "<BR>";

          $url = "luda_api_init.php";         
          echo LUDA_HTML_Link_Show_02( $url, "API&nbsp;&gt;&nbsp;Init..." );
          echo "<BR>";

          echo "</div>";
      echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
                  
                  
              
    
    
    
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle cl_cliccabile" QQQhref="#" id="navbarDropdownDataBase" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          DataBase:                                 
        </a>';       
        echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownDataBase'>";
            $url = $wwwpath . "luda_database_index.php";
            echo LUDA_HTML_Link_Show_02( $url, "Index..." );
            
            //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_stati_OLD";
            //echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_stati_OLD'..." );
            $url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_stati_uda";
            echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_stati_uda'..." );
            $url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_stati_app";
            echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_stati_app'..." );
            $url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_stati_srv";
            echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_stati_srv'..." );
            
            $url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_api_codici";
            echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_api_codici'..." );
            
            $url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_configs";
            echo LUDA_HTML_Link_Show_02( $url, "table&nbsp;'luda_server_configs'..." );
        echo "</div>";
    echo "</li>";  
        
        
     
    
    
    
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle cl_cliccabile" id="navbarDropdownInfo" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Info:                                 
        </a>';       
        echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownInfo'>";
              $url = $wwwpath . "luda_info_index.php";
              echo LUDA_HTML_Link_Show_02( $url, "Index..." );              
        echo "</div>";
    echo "</li>";  
         
    
     
    
    
    
    /* 
    $url = $wwwpath . "luda_status_index.php";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >Status Service...</a>";
    echo "</li>";
    */
    //echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
        
    echo '<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownLayout" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Layout:
        </a>';       
    echo "<div class='dropdown-menu' aria-labelledby='navbarDropdownLayout'>";
          
          $url = $wwwpath . "_LAYOUT.php";
          //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >BootStrap LAYOUT...</a>";
          //echo "<a class='dropdown-item' >" . LUDA_HTML_Link_Show_02( $url, "BootStrap Layout..." ) . "</a>";
          echo  LUDA_HTML_Link_Show_02( $url, "BootStrap Layout..." )  ;

          $url = "https://getbootstrap.com/";
          //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >BootStrap...</a>";
          //echo "<a class='dropdown-item' >" . LUDA_HTML_Link_Show_02( $url, "BootStrap...", "_blank" ) . "</a>";
          echo  LUDA_HTML_Link_Show_02( $url, "BootStrap...", "_blank" ) ;
          
          $url = "https://getbootstrap.com/docs/4.4/getting-started/introduction/";
          //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >BootStrap Documentation...</a>";
          //echo "<a class='dropdown-item' >" . LUDA_HTML_Link_Show_02( $url, "BootStrap Documentation...", "_blank" ) . "</a>";
          echo   LUDA_HTML_Link_Show_02( $url, "BootStrap Documentation...", "_blank" )  ;
          
          echo "<div class='dropdown-divider'></div>";
          echo "<a class='dropdown-item disabled' href='#'>Qualche altra info (NIY)!</a>";
        echo "</div>";
echo "</li>";  
        
    
        
    $url = "http://www.casapaganini.org/Tools/LUDA/";
    echo "<li class='nav-item'>";
        echo "<a class='nav-link' href='" .$url. "' >Demo online @CPIM...</a>";
    echo "</li>";
    echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
        
    

    echo '<li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li>
    </ul>';
//echo "<li class='divider cl_divider_verticale'>&nbsp;</li>";  
        
    
             
    echo "</div>";
    echo "</nav>";
    
    }//LUDA_HTML_HEADER_Navbar_Print
///////////////////////////////////////////////////////////////////

function LUDA_HTML_Link_Show_01( $p_url, $p_text )
    {
    
    $wwwpath = LUDA_WWW_Site_Path_Get_01();

    $config_name = "LUDA_SERVER_MASTER_BUTTONS_LINK";

    $oConfig = new cLUDA_Config( );
    $link_type = $oConfig->Get_ByName_01( $config_name );
    //echo "LINK_TYPE = [" .$link_type. "]<BR>\n";
    
    $url = $wwwpath . $p_url;
    
    switch( $link_type )
        {
        case "ANCHOR":
            echo "<a class='c_luda_server_master_button_link_anchor' href='" .$url. "' QQQtarget='_blank' >" .$p_text. "</a>";            
        break;
        case "BUTTON":
            //echo "<a class='c_luda_server_master_button_link_anchor' href='" .$url. "' QQQtarget='_blank' ><BUTTON>" .$p_text. "</BUTTON></a>";
            echo "<BUTTON onclick='LUDA_Button_Page_Go_01(\"" .$url. "\");' type='button' >" .$p_text. "</BUTTON>";            
        break;
        default:
            echo "ConfigName = [" .$config_name. "] DEFAULT NOT RECOGNIZED!";
            echo "<BR>";
        break;
        }

    }//LUDA_HTML_Link_Show_01
///////////////////////////////////////////////////////////////////
 
function LUDA_HTML_Link_Show_02( $p_url, $p_text, $p_target = "" )
    {
    //$wwwpath = LUDA_WWW_Site_Path_Get_01();
    $config_name = "LUDA_SERVER_MASTER_BUTTONS_LINK";
    $oConfig     = new cLUDA_Config( );
    $link_type   = $oConfig->Get_ByName_01( $config_name );
    //echo "LINK_TYPE = [" .$link_type. "]<BR>\n";
    //$url = $wwwpath . $p_url;
    switch( $link_type )
        {
        case "ANCHOR":
            echo "<a class='c_luda_server_master_button_link_anchor' href='" .$p_url. "' target='" .$p_target. "' >" .$p_text. "</a>";            
        break;
        case "BUTTON":
            //echo "<a class='c_luda_server_master_button_link_anchor' href='" .$url. "' QQQtarget='_blank' ><BUTTON>" .$p_text. "</BUTTON></a>";
            //echo "<BUTTON onclick='LUDA_Button_Page_Go_01(\"" .$url. "\");' type='button' >" .$p_text. "</BUTTON>";            
            switch( $p_target )
                {                                                                                    
                case "":        
                        echo "<BUTTON onclick='LUDA_Button_Page_Go_01(\"" .$p_url. "\");' type='button' style=' QQQbackground:red; background:#AAFFFF; width:100%; ' >" .$p_text. "</BUTTON>";            
                break;
                case "_blank":        
                        echo "<BUTTON onclick='LUDA_Button_Page_Open_01(\"" .$p_url. "\");' type='button' style=' QQQbackground:yellow; background:#AAFFFF; width:100%; ' >" .$p_text. "</BUTTON>";            
                break;
                default:
                      //  echo "<BUTTON onclick='LUDA_Button_Page_EncapsuleIn_01(\"" .$p_url. "\");' type='button' >" .$p_text. "</BUTTON>";            
                      echo "<BUTTON onclick='LUDA_Button_Page_EncapsuleIn_01(\"" .$p_url. "\", \"" .$p_target. "\" );' style=' QQQbackground:yellow; background:#AAFFFF; width:100%; ' type='button' >" .$p_text. "</BUTTON>";            
                break;
                }
        break;
        default:
            echo "ConfigName = [" .$config_name. "] DEFAULT NOT RECOGNIZED!";
            echo "<BR>";
        break;
        }

    }//LUDA_HTML_Link_Show_02
///////////////////////////////////////////////////////////////////
  
function LUDA_HTTP_Parameter_Assign_01( $http_parameter )
    {
    $rv = isset($http_parameter) ? $http_parameter : 0;
    return $rv;
    }//LUDA_HTTP_Parameter_Assign_01
///////////////////////////////////////////////////////////////////

function LUDA_Table_luda_server_stati_Print_01( )
    {
    
// 2020-12-01 -> NON HO "AGGIORNATO" questa function... perche' mi "sembra" obsoleta -> VERIFICARE!!!
    
    $conn = new mysqli("localhost", "root", "", "dbluda");  
    if ($conn->connect_error) {
        die("ERROR: Unable to connect: " . $conn->connect_error);
    } 
    echo 'Connected to the database.<br>';
    $result = $conn->query("SELECT * FROM luda_server_stati; ");
    echo "Number of rows: $result->num_rows";

    /* Select queries return a resultset */
    if ($result = $conn->query("SELECT * FROM luda_server_stati ")) {
        printf("Select returned %d rows.\n", $result->num_rows);
        echo "<TABLE border='1' >";
        while($obj = $result->fetch_object()){
            //var_dump( $obj );
            $line ="";
            $line.="<TR >";
            $line.="<TD >" . $obj->idstato     . "</TD>";
            $line.="<TD >" . $obj->codice      . "</TD>";
            $line.="<TD >" . $obj->descrizione . "</TD>";
            $line.="<TD >" . $obj->stato       . "</TD>";
            $line.="<TD >" . $obj->note        . "</TD>";
            $line.="</TR>";
            echo $line;
        }
        echo "</TABLE>";
        $result->close();
    }
    $conn->close();

    }//LUDA_Table_luda_server_stati_Print_01
///////////////////////////////////////////////////////////////////

//
// Ritorna lo <stato impostato da SRV> della UDA "indicata".
//
function LUDA_UDA_Status_BySrv_Get( $iduda )
    {

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT stato_by_srv AS uda_stato_by_srv ";

// 2020-12-01
if( 0 )
{    
    $query .= "FROM   luda_server_stati   ";
}
else
{
    $query .= "FROM   luda_server_stati_uda   ";
}

    $query .= "WHERE  iduda = '" . $iduda . "' ";
    $result           = $loDB->Query_01($query);
    $num_records      = $loDB->RecordCount_01();
    $record           = $loDB->Fetch_01();
    $uda_stato_by_srv = $record->uda_stato_by_srv;  
    //echo "uda_stato_by_srv = [" .$uda_stato_by_srv. "]<BR>\n";

    // Return value.
    return $uda_stato_by_srv;
 
    }//LUDA_UDA_Status_BySrv_Get
///////////////////////////////////////////////////////////////////
  
//
// Ritorna lo <stato impostato da SRV> della APP "indicata".
//
// 2020-12-01
function LUDA_APP_Status_BySrv_Get( $idapp )
    {

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT stato_by_srv AS app_stato_by_srv ";
    $query .= "FROM   luda_server_stati_app   ";
    $query .= "WHERE  idapp = '" . $idapp . "' ";
    $result           = $loDB->Query_01($query);
    $num_records      = $loDB->RecordCount_01();
    $record           = $loDB->Fetch_01();
    $app_stato_by_srv = $record->app_stato_by_srv;  
    //echo "app_stato_by_srv = [" .$app_stato_by_srv. "]<BR>\n";

    // Return value.
    return $app_stato_by_srv;
 
    }//LUDA_APP_Status_BySrv_Get
///////////////////////////////////////////////////////////////////

//
// Ritorna lo <stato impostato da UDA> della UDA "indicata".
//
function LUDA_UDA_Status_ByUda_Get( $iduda )
    {

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT stato_by_uda AS uda_stato_by_uda ";
// 2020-12-01
if( 0 )
    {
    $query .= "FROM   luda_server_stati     ";
    }
else
    {
    $query .= "FROM   luda_server_stati_uda ";
    }
    $query .= "WHERE  iduda = '" . $iduda . "' ";
    $result           = $loDB->Query_01($query);
    $num_records      = $loDB->RecordCount_01();
    $record           = $loDB->Fetch_01();
    $uda_stato_by_uda = $record->uda_stato_by_uda;  
    //echo "uda_stato_by_uda = [" .$uda_stato_by_uda. "]<BR>\n";

    // Return value.
    return $uda_stato_by_uda;
 
    }//LUDA_UDA_Status_ByUda_Get
///////////////////////////////////////////////////////////////////

//
// Ritorna lo <stato impostato da APP> della APP "indicata".
//
function LUDA_APP_Status_ByApp_Get( $idapp )
    {

    $loDB   = new cLUDA_DB();    
    $query  = "";
    $query .= "SELECT stato_by_app AS app_stato_by_app ";
    $query .= "FROM   luda_server_stati_app ";
    $query .= "WHERE  idapp = '" . $idapp . "' ";
    $result           = $loDB->Query_01($query);
    $num_records      = $loDB->RecordCount_01();
    $record           = $loDB->Fetch_01();
    $app_stato_by_app = $record->app_stato_by_app;  
    //echo "app_stato_by_app = [" .$app_stato_by_app. "]<BR>\n";

    // Return value.
    return $app_stato_by_app;
 
    }//LUDA_APP_Status_ByApp_Get
///////////////////////////////////////////////////////////////////
   
function LUDA_Table_luda_server_stati_Print_02( )
    {
    
// 2020-12-01 -> NON HO "AGGIORNATO" questa function... perche' mi "sembra" obsoleta -> VERIFICARE!!!
    
    $loDB = new cLUDA_DB();
    $query = "SELECT * FROM luda_server_stati";
    $result = $loDB->Query_01($query);
    $num_records = $loDB->RecordCount_01();
    $columns_name = $loDB->ColumnsName_01();
    //var_dump( $columns_name );
    //exit();
    
    echo "Number of rows: $num_records";

    /* Select queries return a resultset */
    if ( ! is_null($result) ) 
        {
        printf( "Select returned row number = %d .\n", $num_records );
        echo "<TABLE border='1' >";
        
        // Header.
        $line  = "";
        $line .= "<TR class='cl_table_header_columns_name' >";
        foreach( $columns_name as $col_num => $col_name )
            {
            $line .= "<TD >" .$col_name. "</TD>";
            }
        $line .= "</TR>";
        
        echo $line;
        //echo $line;
      //exit();
      
        // Data.
        // while($obj = $result->fetch_object())
        while( $obj = $loDB->Fetch_01() )
            {
            //var_dump( $obj );
            $line ="";
            $line.="<TR >";
            $line.="<TD >" . $obj->iduda       . "</TD>";
            $line.="<TD >" . $obj->codice      . "</TD>";
            $line.="<TD >" . $obj->descrizione . "</TD>";
            $line.="<TD >" . $obj->stato_srv   . "</TD>";
            $line.="<TD >" . $obj->stato_uda   . "</TD>";
            $line.="<TD >" . $obj->note        . "</TD>";
            $line.="</TR>";
            echo $line;
            }
        echo "</TABLE>";
        }
    $loDB->Finish_01();
//exit();
      
    }//LUDA_Table_luda_server_stati_Print_02
///////////////////////////////////////////////////////////////////

function LUDA_WWW_Root_Path_Get_01( )
    {
//echo "LUDA_CONSTANT_SERVER_ADDR = [" .LUDA_CONSTANT_SERVER_ADDR. "]<BR>\n";
    
//var_dump( $_SERVER );
//exit();
/*
'DOCUMENT_ROOT'         => string 'C:/wamp64/www'  
'CONTEXT_DOCUMENT_ROOT' => string 'C:/wamp64/www' 
'SCRIPT_FILENAME'       => string 'C:/wamp64/www/luda/index.php' 
'REQUEST_URI'           => string '/luda/index.php'  
'SCRIPT_NAME'           => string '/luda/index.php'  
'PHP_SELF'              => string '/luda/index.php' 
*/
$l_DOCUMENT_ROOT         = $_SERVER[ 'DOCUMENT_ROOT'         ];  // 'C:/wamp64/www'  
$l_CONTEXT_DOCUMENT_ROOT = $_SERVER[ 'CONTEXT_DOCUMENT_ROOT' ];  // 'C:/wamp64/www' 
$l_SCRIPT_FILENAME       = $_SERVER[ 'SCRIPT_FILENAME'       ];  // 'C:/wamp64/www/luda/index.php' 
$l_REQUEST_URI           = $_SERVER[ 'REQUEST_URI'           ];  // 'C:/wamp64/www/luda/index.php' 
$l_SCRIPT_NAME           = $_SERVER[ 'SCRIPT_NAME'           ];  // 'C:/wamp64/www/luda/index.php' 
$l_PHP_SELF              = $_SERVER[ 'PHP_SELF'              ];  // 'C:/wamp64/www/luda/index.php' 

    // str_replace ( mixed $search , mixed $replace , mixed $subject [, int &$count ] ) : mixed
    $url = $l_SCRIPT_FILENAME;
//echo "WEB_ROOT = [" .$url. "]<BR>\n";
    $url = str_replace( $l_CONTEXT_DOCUMENT_ROOT     , "" , $url ); 
//echo "WEB_ROOT = [" .$url. "]<BR>\n";
//  $url = str_replace( dirname($l_PHP_SELF)                  , "" , $url ); 
  $url = dirname($l_PHP_SELF) . "/"       ; //          , "" , $url ); 
//echo "WEB_ROOT = [" .$url. "]<BR>\n";
 //   $url = str_replace( LUDA_CONSTANT_SERVER_ADDR , "" , $url ); 
//echo "WEB_ROOT = [" .$url. "]<BR>\n";

//exit();
    return $url;         
    }//LUDA_WWW_Root_Path_Get_01     
///////////////////////////////////////////////////////////////////

function LUDA_WWW_Site_Path_Get_01( )
    {
    //$url = LUDA_WWW_Root_Path_Get_01() . "/" . LUDA_CONSTANT_SERVER_ADDR . "/"; 
    $url = LUDA_WWW_Root_Path_Get_01() ; // . "/" . LUDA_CONSTANT_SERVER_ADDR . "/"; 
    //echo "WEB_SITE_ROOT = [" .$url. "]<BR>\n";
    return $url;     
    }//LUDA_WWW_Site_Path_Get_01     
///////////////////////////////////////////////////////////////////

function Test_01( )
{
}


function Test_02( )
  {
    
// 2020-12-01 -> NON HO "AGGIORNATO" questa function... perche' mi "sembra" obsoleta -> VERIFICARE!!!
    
  $conn = new mysqli("localhost", "root", "", "dbluda");
  if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
  } 
  echo 'Connected to the database.<br>';
  $result = $conn->query("SELECT * FROM luda_server_stati; ");
  echo "Number of rows: $result->num_rows";
  if ($result = $conn->query("SELECT * FROM luda_server_stati ")) {
    printf("Select returned %d rows.\n", $result->num_rows);
        echo "<TABLE border='1' >";
        while($obj = $result->fetch_object()){
            //var_dump( $obj );
            $line ="";
            $line.="<TR >";
            $line.="<TD >" . $obj->idstato     . "</TD>";
            $line.="<TD >" . $obj->codice      . "</TD>";
            $line.="<TD >" . $obj->descrizione . "</TD>";
            $line.="<TD >" . $obj->stato       . "</TD>";
            $line.="<TD >" . $obj->note        . "</TD>";
            $line.="</TR>";
            echo $line;
        }
        echo "</TABLE>";
    $result->close();
  }
  $conn->close();
  }//Test_02

function Test_03( )
    {
    $conn = new mysqli("localhost", "root", "", "dbluda");
    if ($conn->connect_error) {
      die("ERROR: Unable to connect: " . $conn->connect_error);
    } 
    if ($result = $conn->query("SELECT * FROM luda_server_api_codici ")) {
        printf("Select returned %d rows.\n", $result->num_rows);
        echo "<TABLE border='1' >";
        while($obj = $result->fetch_object()){
              //var_dump( $obj );
              $line ="";
              $line.="<TR >";
              $line.="<TD >" . $obj->tipo     . "</TD>";
              $line.="<TD >" . $obj->codice      . "</TD>";
              $line.="<TD >" . $obj->funzione . "</TD>";
              $line.="<TD >" . $obj->num_parametri . "</TD>";
              $line.="<TD >" . $obj->nome      . "</TD>";
              $line.="<TD >" . $obj->descrizione . "</TD>";
              $line.="<TD >" . $obj->note        . "</TD>";
              $line.="</TR>";
              echo $line;
          }//while
          echo "</TABLE>";
      $result->close();
    }
    $conn->close();
    }//Test_03


?>