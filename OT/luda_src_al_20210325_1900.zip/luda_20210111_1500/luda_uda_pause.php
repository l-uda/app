<?php
session_start();
require_once( "./luda_include_config.php"    );
require_once( "./luda_include_functions.php" );
require_once( "./luda_class_db.php"          );
require_once( "./luda_class_api.php"         );

echo "API::SRV::PUT";
$l_sTipo     = LUDA_CONSTANT_SERVER_TIPO_SRV;
$l_sFunzione = LUDA_CONSTANT_SERVER_FUNZIONE_PUT;

//var_dump( $_GET );
$par_iI = LUDA_API_Parameters_GetFromREST( $_GET, 'i' );
//$par_iK = LUDA_API_Parameters_GetFromREST( $_GET, 'k' );
 
$oAPI = new cLUDA_API( $l_sTipo );
 
//if( $l_sFunzione == LUDA_CONSTANT_SERVER_FUNZIONE_PUT ) { $stato = $oAPI->Put_01( $par_iI, $par_iK ); }
//if( $l_sFunzione == LUDA_CONSTANT_SERVER_FUNZIONE_GET ) { $stato = $oAPI->Get_01( $par_iI          ); }
//echo "STATO = <B >[" .$stato. "]</B>";
//echo "<BR />\n";

$command_name = LUDA_CONSTANT_COMMAND_API_SRV_PUT_NAME_PAUSE;
$command_code = LUDA_API_Command_Get_CodeByName( $l_sTipo, $l_sFunzione, $command_name );
//$command_code = 1;


//for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
$esploratore = $par_iI;
    {//for_esploratore_strt
    $stato = $oAPI->Put_01( $esploratore, $command_code ); 
    echo "STATO = <B >[" .$stato. "]</B>";
    }//for_esploratore_stop



?>