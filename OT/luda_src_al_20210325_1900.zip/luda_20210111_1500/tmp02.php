<!--
<a href='https://www.zapsplat.com/wp-content/uploads/2015/sound-effects-35448/zapsplat_multimedia_button_press_plastic_click_004_36871.mp3?_=4' >down...</a>    
!-->


<PRE >

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE `luda_server_stati` (
  `idstato` int(11) NOT NULL auto_increment,
  `codice` varchar(16) default NULL,
  `descrizione` varchar(64) NOT NULL,
  `stato` int(11) default '0',
  `note` varchar(256) NOT NULL,
  PRIMARY KEY  (`idstato`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(1, 'UDA1', 'Postazione UDA N.1', 0, 'Gestione della Postazione UDA N.1');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(2, 'UDA2', 'Postazione UDA N.2', 0, 'Gestione della Postazione UDA N.2');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(3, 'UDA3', 'Postazione UDA N.3', 0, 'Gestione della Postazione UDA N.3');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(4, 'UDA4', 'Postazione UDA N.4', 0, 'Gestione della Postazione UDA N.4');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(5, 'UDA5', 'Postazione UDA N.5', 0, 'Gestione della Postazione UDA N.5');
INSERT INTO `luda_server_stati` (`idstato`, `codice`, `descrizione`, `stato`, `note`) VALUES(6, 'MSTR', 'Postazione Master!', 0, 'Gestione della Postazione Master!');

</PRE>


<?php               

exit();
 
if( 0 )
{
$homepage = file_get_contents( "http://localhost/" );
echo $homepage;
}
 

if( 0 )
{
$homepage = file_get_contents( "http://localhost/phpmyadmin/" );
echo $homepage;
}


?>


<?php
//Test_02();
//Test_03();
//LUDA_Table_luda_server_stati_Print_01();
//echo "<HR>";
//LUDA_Table_luda_server_stati_Print_02();
?>



<?php
if( 0 )
{
/*
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
for( $rrr = 1; $rrr <= $num_records; $rrr++ )
    {//for_strt
    echo "<HR>";
    echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
    $record = $oDB->Fetch_01();
    var_dump( $record );
    }//for_stop
*/
}
?>
<HR>
<HR>
<HR>




 
 
 
 
 
 
 
<?php
//$oDB->Table_Print_01( "luda_server_stati" );
//echo "<BR>";

//$oDB->Table_Print_01( "luda_server_api_codici" );  
//echo "<BR>";
?>

 
 
<CENTER >
<DIV id='div_server_master_controls' >
<TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >

    <TR>
        <TD colspan='4' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Comandi Generali</CENTER></TD>
    </TR>
    
  

</TABLE></DIV>
</CENTER>



<HR>
<A href='img/LUDA_server_API_info_01.png' target='_blank' ><IMG src='img/LUDA_server_API_info_01.png' ></A>
<HR>


<HR>
<HR>
<HR>
<HR>







<?php

// Codici SERVER :: GET.
$api_tipo     = "SRV";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici SERVER :: PUT.
$api_tipo     = "SRV";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: GET.
$api_tipo     = "UDA";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: PUT.
$api_tipo     = "UDA";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
 
?>
 
<HR>
<HR>
<HR>






 
 
 
  

<?php
  
function StampaTabellaCodici_01_OLD_01( $p_sTipo )
    {
    $loDB = new cLUDA_DB();

    echo "<H3>CODICI &bull; " .$p_sTipo. " UDA</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD >GET(i)</TD><TD >PUT(i,k)</TD></TR>";    
    $max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
    for( $ccc = 0; $ccc <= $max_codice_tipo; $ccc++ )
        {//for_strt
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' ORDER BY codice, funzione ";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo. ")</TD></TR>";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_GET = $loDB->Fetch_01();
        $recordset_PUT = $loDB->Fetch_01();
        echo "<TR>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_GET ); echo "</TD>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        echo "<TR >";
            if( is_null($recordset_GET) )
                {
                $data_GET  = "";
                }
            else
                {
                $data_GET  = "";
                $data_GET .= $recordset_GET->codice;
                $data_GET .= ": ";
                $data_GET .= $recordset_GET->nome;
                $data_GET .= "<br>";
                $data_GET .= $recordset_GET->funzione;
                $data_GET .= ($recordset_GET->num_parametri == "1" ? "(i)"   : "");
                $data_GET .= "";
                }
            if( is_null($recordset_PUT) )
                {
                $data_PUT  = "";
                }
            else
                {
                $data_PUT  = "";
                $data_PUT .= $recordset_PUT->codice;
                $data_PUT .= ": ";
                $data_PUT .= $recordset_PUT->nome;
                $data_PUT .= "<br>";
                $data_PUT .= $recordset_PUT->funzione;
                $data_PUT .= ($recordset_PUT->num_parametri == "2" ? "(i,k)" : "");
                $data_PUT .= "";
                }
            echo "<TD >" .$data_GET. "</TD>";
            echo "<TD >" .$data_PUT. "</TD>";
        echo "</TR>";
        echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_01
    
?>






<?php



function StampaTabellaCodici_02_OLD( $p_sTipo, $p_sFunzione )
    {
    $loDB = new cLUDA_DB();
    echo "<H3>CODICI: " .$p_sTipo. " API &bull; " .$p_sFunzione. "</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD >GET(i)</TD><TD >PUT(i,k)</TD></TR>";    
    //$max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
    $max_codice_tipo_and_function = $loDB->GetMaxCodiceAPIbyTipoAndFunzione( $p_sTipo, $p_sFunzione );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
     
    for( $ccc = 0; $ccc <= $max_codice_tipo_and_function; $ccc++ )
        {//for_strt
        
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' AND funzione = '" .$p_sFunzione. "' ORDER BY codice ";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
       
        
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo_and_function. ")</TD></TR>";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_function = $loDB->Fetch_01();
        //$recordset_PUT = $loDB->Fetch_01();
        echo "<TR>";
            echo "<TD colspan='100%' style=' background:gray; ' >"; var_dump( $recordset_function ); echo "</TD>";
            //echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        echo "<TR >";
            if( is_null($recordset_function) )
                {
                $data_function  = "";
                }
            else
                {
                $data_function  = "";
                $data_function .= $recordset_function->codice;
                $data_function .= ": ";
                $data_function .= $recordset_function->nome;
                $data_function .= "<br>";
                $data_function .= $recordset_function->funzione;
                $data_function .= ($recordset_function->num_parametri == "1" ? "(i)"   : "");
                $data_function .= ($recordset_function->num_parametri == "2" ? "(i,k)" : "");
                $data_function .= "";
                }
            echo "<TD colspan='100%' >" .$data_function. "</TD>";
        echo "</TR>";
        echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_02
      
?>



<?php
/*
echo "<HR />\n";

$p_sTipo = "SRV";
Stampa_Tabella_API_Test_01( $p_sTipo );
echo "<BR />\n";

$p_sTipo = "UDA";
Stampa_Tabella_API_Test_01( $p_sTipo );
echo "<BR />\n";
 
echo "<HR />\n";
*/


$oDB->Table_Print_01( "luda_server_stati" );
echo "<BR>";


?>





<?php

function Stampa_Tabella_API_Test_01( $p_sTipo )
    {
    global $max_codice_SRV;
    global $max_codice_UDA;
    global $g_server_esploratori_qty;

$l_oDB           = new cLUDA_DB  ();    
$max_codice_SRV  = $l_oDB->GetMaxCodiceAPIbyTipo( "SRV" );
$max_codice_UDA  = $l_oDB->GetMaxCodiceAPIbyTipo( "UDA" );
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;

    
    echo "<TABLE border='1' >";
    echo "<TR class='cl_table_header_columns_name' >";
        echo "<TD colspan='100%' ><h2>API &bull; " .$p_sTipo. "</h2></TD>";
    echo "</TR>";  
    echo "<TR class='cl_table_header_columns_subname' >";
        echo "<TD colspan='2' ><h3>GET</h3></TD>";
        echo "<TD colspan='8' ><h3>PUT</h3></TD>";
    echo "</TR>";  
    for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
        {//for_esploratore_strt
        $idf_srv = "frm_srv_" .strtolower($p_sTipo). "_" .$esploratore;
        $idf_uda = "frm_uda_" .strtolower($p_sTipo). "_" .$esploratore;        
//      $url_srv = "/luda/api/" .strtolower($p_sTipo). "/get/?i=" .$esploratore;
        $url_srv = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/get/?i=" .$esploratore;
        echo "<TR>";
            echo "<TD colspan='1' >";
                echo "<A href='" .$url_srv. "' target='" .$idf_srv. "' >" .strtolower($p_sTipo) . "/get/?i=" .$esploratore. "</A>";
            echo "</TD>";
            echo "<TD colspan='1' >";
                echo "<IFRAME id='" .$idf_srv. "' name='" .$idf_srv. "' QQQsrc='" .$url_srv. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
            echo "</TD>";
            for( $codice = 1; $codice <= $max_codice_UDA; $codice++ )
                {//for_uda_strt
                //$url_uda = "/luda/api/" .strtolower($p_sTipo). "/put/?i=" .$esploratore . "&k=" . $codice;
                $url_uda = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;
                echo "<TD colspan='1' >";
                    echo "<A href='" .$url_uda. "' target='" .$idf_uda. "' >" .strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice. "</A>";
                echo "</TD>";
                }//for_uda_stop
            echo "<TD colspan='1' >";
                echo "<IFRAME id='" .$idf_uda. "' name='" .$idf_uda. "' QQQsrc='" .$url_uda. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
            echo "</TD>";
            
        echo "</TR>";  
          echo "<TR>";
            echo "<TD colspan='100%' >&nbsp;</TD>";
        echo "</TR>";  
        }//for_esploratore_stop
    echo "</TABLE>";
    }//Stampa_API_Test_01


exit();

?>
 
 
 
 
 
 
<?php
//$oDB->Table_Print_01( "luda_server_stati" );
//echo "<BR>";

//$oDB->Table_Print_01( "luda_server_api_codici" );  
//echo "<BR>";
?>

 
 
<CENTER >
<DIV id='div_server_master_controls' >
<TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >

    <TR>
        <TD colspan='4' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Comandi Generali</CENTER></TD>
    </TR>
    
  

</TABLE></DIV>
</CENTER>


<?php
//Test_02();
//Test_03();
//LUDA_Table_luda_server_stati_Print_01();
//echo "<HR>";
//LUDA_Table_luda_server_stati_Print_02();
?>

<HR>
<A href='img/LUDA_server_API_info_01.png' target='_blank' ><IMG src='img/LUDA_server_API_info_01.png' ></A>
<HR>


<HR>
<HR>
<HR>
<HR>



<?php
if( 0 )
{
/*
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
for( $rrr = 1; $rrr <= $num_records; $rrr++ )
    {//for_strt
    echo "<HR>";
    echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
    $record = $oDB->Fetch_01();
    var_dump( $record );
    }//for_stop
*/
}
?>
<HR>
<HR>
<HR>


<?php

// Codici SERVER :: GET.
$api_tipo     = "SRV";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici SERVER :: PUT.
 

function Stampa_Tabella_API_Test_01_OLD_01_02( $p_sTipo )
    {
    global $max_codice_SRV;
    global $max_codice_UDA;
    global $g_server_esploratori_qty;

$l_oDB           = new cLUDA_DB  ();    
$max_codice_SRV  = $l_oDB->GetMaxCodiceAPIbyTipo( "SRV" );
$max_codice_UDA  = $l_oDB->GetMaxCodiceAPIbyTipo( "UDA" );
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;

    
    echo "<TABLE border='1' >";
    echo "<TR class='cl_table_header_columns_name' >";
        echo "<TD colspan='100%' ><h2>API &bull; " .$p_sTipo. "</h2></TD>";
    echo "</TR>";  
    echo "<TR class='cl_table_header_columns_subname' >";
        echo "<TD colspan='2' ><h3>GET</h3></TD>";
        echo "<TD colspan='8' ><h3>PUT</h3></TD>";
    echo "</TR>";  
    for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
        {//for_esploratore_strt
        $idf_srv = "frm_srv_" .strtolower($p_sTipo). "_" .$esploratore;
        $idf_uda = "frm_uda_" .strtolower($p_sTipo). "_" .$esploratore;        
//      $url_srv = "/luda/api/" .strtolower($p_sTipo). "/get/?i=" .$esploratore;
        $url_srv = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/get/?i=" .$esploratore;
        echo "<TR>";
            echo "<TD colspan='1' >";
                echo "<A href='" .$url_srv. "' target='" .$idf_srv. "' >" .strtolower($p_sTipo) . "/get/?i=" .$esploratore. "</A>";
            echo "</TD>";
            echo "<TD colspan='1' >";
                echo "<IFRAME id='" .$idf_srv. "' name='" .$idf_srv. "' QQQsrc='" .$url_srv. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
            echo "</TD>";
            for( $codice = 1; $codice <= $max_codice_UDA; $codice++ )
                {//for_uda_strt
                //$url_uda = "/luda/api/" .strtolower($p_sTipo). "/put/?i=" .$esploratore . "&k=" . $codice;
                $url_uda = LUDA_CONSTANT_SERVER_API_ADDR . strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice;
                echo "<TD colspan='1' >";
                    echo "<A href='" .$url_uda. "' target='" .$idf_uda. "' >" .strtolower($p_sTipo) . "/put/?i=" .$esploratore . "&k=" . $codice. "</A>";
                echo "</TD>";
                }//for_uda_stop
            echo "<TD colspan='1' >";
                echo "<IFRAME id='" .$idf_uda. "' name='" .$idf_uda. "' QQQsrc='" .$url_uda. "' style=' height:100px; width:200px; ' >- - -</IFRAME>";
            echo "</TD>";
            
        echo "</TR>";  
          echo "<TR>";
            echo "<TD colspan='100%' >&nbsp;</TD>";
        echo "</TR>";  
        }//for_esploratore_stop
    echo "</TABLE>";
    }//Stampa_API_Test_01


exit();

?>
 
 
 
 
 
 
 
<?php
//$oDB->Table_Print_01( "luda_server_stati" );
//echo "<BR>";

//$oDB->Table_Print_01( "luda_server_api_codici" );  
//echo "<BR>";
?>

 
 
<CENTER >
<DIV id='div_server_master_controls' >
<TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >

    <TR>
        <TD colspan='4' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Comandi Generali</CENTER></TD>
    </TR>
    
  

</TABLE></DIV>
</CENTER>


<?php
//Test_02();
//Test_03();
//LUDA_Table_luda_server_stati_Print_01();
//echo "<HR>";
//LUDA_Table_luda_server_stati_Print_02();
?>

<HR>
<A href='img/LUDA_server_API_info_01.png' target='_blank' ><IMG src='img/LUDA_server_API_info_01.png' ></A>
<HR>


<HR>
<HR>
<HR>
<HR>



<?php
if( 0 )
{
/*
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
for( $rrr = 1; $rrr <= $num_records; $rrr++ )
    {//for_strt
    echo "<HR>";
    echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
    $record = $oDB->Fetch_01();
    var_dump( $record );
    }//for_stop
*/
}
?>
<HR>
<HR>
<HR>



<?php
  
function StampaTabellaCodici_01( $p_sTipo )
    {
    $loDB = new cLUDA_DB();

    echo "<H3>CODICI &bull; " .$p_sTipo. " UDA</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD >GET(i)</TD><TD >PUT(i,k)</TD></TR>";    
    $max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
    for( $ccc = 0; $ccc <= $max_codice_tipo; $ccc++ )
        {//for_strt
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' ORDER BY codice, funzione ";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo. ")</TD></TR>";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_GET = $loDB->Fetch_01();
        $recordset_PUT = $loDB->Fetch_01();
        echo "<TR>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_GET ); echo "</TD>";
            echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        echo "<TR >";
            if( is_null($recordset_GET) )
                {
                $data_GET  = "";
                }
            else
                {
                $data_GET  = "";
                $data_GET .= $recordset_GET->codice;
                $data_GET .= ": ";
                $data_GET .= $recordset_GET->nome;
                $data_GET .= "<br>";
                $data_GET .= $recordset_GET->funzione;
                $data_GET .= ($recordset_GET->num_parametri == "1" ? "(i)"   : "");
                $data_GET .= "";
                }
            if( is_null($recordset_PUT) )
                {
                $data_PUT  = "";
                }
            else
                {
                $data_PUT  = "";
                $data_PUT .= $recordset_PUT->codice;
                $data_PUT .= ": ";
                $data_PUT .= $recordset_PUT->nome;
                $data_PUT .= "<br>";
                $data_PUT .= $recordset_PUT->funzione;
                $data_PUT .= ($recordset_PUT->num_parametri == "2" ? "(i,k)" : "");
                $data_PUT .= "";
                }
            echo "<TD >" .$data_GET. "</TD>";
            echo "<TD >" .$data_PUT. "</TD>";
        echo "</TR>";
        echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_01
?>





 

<?php

// Codici SERVER :: GET.
$api_tipo     = "SRV";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici SERVER :: PUT.
$api_tipo     = "SRV";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: GET.
$api_tipo     = "UDA";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: PUT.
$api_tipo     = "UDA";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
 
?>
 
<HR>
<HR>
<HR>






<?php    


function StampaTabellaCodici_02( $p_sTipo, $p_sFunzione )
    {
    $loDB = new cLUDA_DB();
    echo "<H3>CODICI: " .$p_sTipo. " API &bull; " .$p_sFunzione. "</H3>\n";
    echo "<TABLE border='5' >";
    echo "<TR style=' background:yellow; text-align:center; ' ><TD colspan='100%' >" .$p_sTipo. " API</TD></TR>";    
    echo "<TR style=' background:orange; text-align:center; ' ><TD >GET(i)</TD><TD >PUT(i,k)</TD></TR>";    
    //$max_codice_tipo = $loDB->GetMaxCodiceAPIbyTipo( $p_sTipo );
    $max_codice_tipo_and_function = $loDB->GetMaxCodiceAPIbyTipoAndFunzione( $p_sTipo, $p_sFunzione );
//  echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//  $max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//  Massimo codice (indipendentemente da SRV oppure UDA).
//  $max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;    
     
    for( $ccc = 0; $ccc <= $max_codice_tipo_and_function; $ccc++ )
        {//for_strt
        
        $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND codice = '" .$ccc. "' AND funzione = '" .$p_sFunzione. "' ORDER BY codice ";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >QUERY = [" .$query. "]</TD></TR>";    
        $loDB->Query_01( $query );
        $num_records = $loDB->RecordCount_01();
       
        
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Record N.(" .$ccc. ") di (" .$max_codice_tipo_and_function. ")</TD></TR>";
        echo "<TR><TD colspan='100%' style=' background:gray; ' >Numero di righe ritornate = " . $num_records  . "</TD></TR>";
        $recordset_function = $loDB->Fetch_01();
        //$recordset_PUT = $loDB->Fetch_01();
        echo "<TR>";
            echo "<TD colspan='100%' style=' background:gray; ' >"; var_dump( $recordset_function ); echo "</TD>";
            //echo "<TD QQQcolspan='100%' style=' background:gray; ' >"; var_dump( $recordset_PUT ); echo "</TD>";
        echo "</TR>";
        echo "<TR >";
            if( is_null($recordset_function) )
                {
                $data_function  = "";
                }
            else
                {
                $data_function  = "";
                $data_function .= $recordset_function->codice;
                $data_function .= ": ";
                $data_function .= $recordset_function->nome;
                $data_function .= "<br>";
                $data_function .= $recordset_function->funzione;
                $data_function .= ($recordset_function->num_parametri == "1" ? "(i)"   : "");
                $data_function .= ($recordset_function->num_parametri == "2" ? "(i,k)" : "");
                $data_function .= "";
                }
            echo "<TD colspan='100%' >" .$data_function. "</TD>";
        echo "</TR>";
        echo "<TR><TD colspan='100%' style=' background:#404040; ' >&nbsp;</TD></TR>";    
        }//for_stop
    echo "</TABLE>";
    
    $loDB->Finish_01();
    }//StampaTabellaCodici_02
      
?>

$api_tipo     = "SRV";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: GET.
$api_tipo     = "UDA";
$api_funzione = "GET";
StampaTabellaCodici_02( $api_tipo, $api_funzione );

// Codici UDA :: PUT.
$api_tipo     = "UDA";
$api_funzione = "PUT";
StampaTabellaCodici_02( $api_tipo, $api_funzione );
 
?>
 
<HR>
<HR>
<HR>

<?php
/*
echo "<HR />\n";

$p_sTipo = "SRV";
Stampa_Tabella_API_Test_01( $p_sTipo );
echo "<BR />\n";

$p_sTipo = "UDA";
Stampa_Tabella_API_Test_01( $p_sTipo );
echo "<BR />\n";
 
echo "<HR />\n";
*/
?>


<?php
//echo "<HR>";
$max_codice_SRV = $oDB->GetMaxCodiceAPIbyTipo( "SRV" );
//echo "Max_Codice_SRV = [" .$max_codice_SRV. "]<BR>\n";
//echo "<HR>";

//echo "<HR>";
$max_codice_UDA = $oDB->GetMaxCodiceAPIbyTipo( "UDA" );
//echo "Max_Codice_UDA = [" .$max_codice_UDA. "]<BR>\n";
//echo "<HR>";

// Massimo codice (indipendentemente da SRV oppure UDA).
$max_codice_tipo = $max_codice_SRV > $max_codice_UDA ? $max_codice_SRV : $max_codice_UDA ;
//echo "Max_Codice_TIPO = [" .$max_codice_tipo. "]<BR>\n";
//echo "<HR>";
?>




 
 
<?php
/*
$oDB->Table_Print_01( "luda_server_stati" );
echo "<BR>";

$oDB->Table_Print_01( "luda_server_api_codici" );  
echo "<BR>";
*/
?>



 
<!-- 
<CENTER >
<DIV id='div_server_master_controls' >
<TABLE border='1' cellpadding='10' cellspacing=0 id='table_server_master_controls' >

    <TR>
        <TD colspan='4' style=' font-size:20px; font-weight:bold; text-align:center; ' ><CENTER >Comandi Generali</CENTER></TD>
    </TR>
 !-->   
 

    <?php
    /*
    for( $esploratore = 1; $esploratore <= $g_server_esploratori_qty; $esploratore++ )
        {//for_esploratore_strt
        echo "<TR>";
            echo "<TD colspan='4' ><CENTER ><HR >UDA " .$esploratore. "</CENTER></TD>";
        echo "</TR>";  
          echo "<TR>";
            echo "<TD colspan='4' >&nbsp;</TD>";
        echo "</TR>";  
        }//for_esploratore_stop
    */
    ?>

<!--
</TABLE></DIV>
</CENTER>
!-->








<?php


//Test_02();

//Test_03();


//LUDA_Table_luda_server_stati_Print_01();

echo "<HR>";

//LUDA_Table_luda_server_stati_Print_02();

?>




<HR>
<HR>
<HR>
<HR>



<?php
if( 0 )
{
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
for( $rrr = 1; $rrr <= $num_records; $rrr++ )
    {//for_strt
    echo "<HR>";
    echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
    $record = $oDB->Fetch_01();
    var_dump( $record );
    }//for_stop
}
?>


<HR>
<HR>
<HR>





<?php
/*
// Codici SERVER.
$api_tipo = "SRV";
echo "<H3>CODICI &bull; " .$api_tipo. " UDA</H3>\n";
echo "<TABLE border='1' >";
for( $ccc = 1; $ccc <= $max_codice_tipo; $ccc++ )
    {//for_strt
    $query = "SELECT * FROM luda_server_api_codici WHERE tipo='" .$api_tipo. "' AND codice = '" .$ccc. "' ORDER BY codice, funzione ";
    echo "QUERY = [" .$query. "]<BR>\n";    
    $oDB->Query_01( $query );
    $num_records = $oDB->RecordCount_01();
    echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
    echo "Numero di righe ritornate = " . $num_records  . "<br>";
    $recordset_GET = $oDB->Fetch_01();
    $recordset_PUT = $oDB->Fetch_01();
    var_dump( $recordset_GET );
    var_dump( $recordset_PUT );
    echo "<HR>";
    }//for_stop
echo "</TABLE>";
*/
?>


<?php
// Codici SERVER.
//$api_tipo = "SRV";
//StampaTabellaCodici_01( $api_tipo );
?>





<?php
/*                                                        
echo "<HR />";
echo "<A href='/luda/' >Home!</A>";
echo "<BR />\n";
echo "<A href='update' >Update Service...</A>";
echo "<BR />\n";
echo "<A href='luda_api_index.php' >API Service...</A>";
echo "<BR />\n";
echo "<A href='luda_status_index.php' >Status Service...</A>";
echo "<BR />\n";
echo "<A href='http://www.casapaganini.org/Tools/LUDA/' target='_blank' >Demo online @CPIM...</A>";
echo "<BR />\n";
echo "<HR />\n";
*/
?>
 
 
 
 
     
     
<!--
        <TR>
            <TD colspan='100%' style=' font-size:20px; font-weight:bold; text-align:center; ' >
!-->
            <?php
            //$url = $wwwpath . "luda_database_index.php";
            //echo "<a class='dropdown-item' href='" .$url. "' target='_blank' >Index...</a>";
            //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_stati";
            //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_stati'...</a>";
            //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_api_codici";
            //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_api_codici'...</a>";
            //$url = $wwwpath . "luda_database_table_list.php?tablename=luda_server_configs";
            //echo "<a class='dropdown-item' href='" .$url. "' QQQtarget='_blank' >table 'luda_server_configs'...</a>";
            ?>  
<!--
            </TD>
        </TR>
!-->     





/*
qqq000    
$oDB->Query_01( "SELECT * FROM luda_server_api_codici WHERE tipo='SRV' ORDER BY codice, funzione " );
$num_records = $oDB->RecordCount_01();
echo "Numero di righe ritornate = " . $num_records  . "<br>";
$recordset = $oDB->Result_01();
var_dump( $recordset );
echo "Record N.(" .$rrr. ") di (" .$num_records. ")<BR>\n";
$record = $oDB->Fetch_01();
var_dump( $record );
qqq111
*/






    /*
    // property declaration
    public $var = 'a default value';

    private $mDB_conn = NULL;  // Connessione al Database.
    
    private $mDB_result = NULL;  // Result of (last executed) query.
    
    private $mDB_record_count = 0;  // Record count (dell'ultima query).
    
    function __construct() {
        //print "cLUDA_DB :: constructor\n";
        
        $this->mDB_conn = new mysqli("localhost", "root", "", "dbluda");
  
    if ($this->mDB_conn->connect_error) {
        die("ERRORE: Impossibile connettersi al DataBase: [" . $this->mDB_conn->connect_error . "]" );
        } 
      
    }//__construct

    public function Query_01( $p_sQuery )
        {
        $this->mDB_result = $this->mDB_conn->query( $p_sQuery );
    
        $this->mDB_record_count = $this->mDB_result->num_rows;
        
        //echo "Number of rows: " . $this->mDB_record_count . "";
    
        return $this->mDB_result;
        }//Query_01     
 
    public function RecordCount_01( )
        {
        return $this->mDB_record_count . "";
        }//RecordCount_01     
 
 
    public function ColumnsName_01( )
        {
        $aColumnsName = Array();
        
        $values = $this->mDB_result->fetch_all(MYSQLI_ASSOC);

$b_seek_zero = $this->mDB_result->data_seek (0);
//$columns = array();

        if(!empty($values)){
            $aColumnsName = array_keys($values[0]);
            }
        
        // Return value.
        return $aColumnsName;
        
        }//RecordCount_01

    public function Result_01( )
        {
        return $this->mDB_result;
        }//Result_01     
 

    public function Fetch_01( )
        {
        $obj = $this->mDB_result->fetch_object();
        return $obj;
        }//Fetch_01
 
    public function GetMaxCodiceAPIbyTipo( $p_sTipo )
        {
        $query = "SELECT MAX(codice) AS max_codice_tipo FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' ";
        echo "QUERY = [" .$query. "]<BR>\n";
        $this->Query_01( $query );
        $result = $this->Fetch_01();
        //var_dump( $result );
        //exit();
        $max_codice_tipo = $result->max_codice_tipo;
        return $max_codice_tipo;
    }//GetMaxCodiceAPIbyTipo    
    

    public function GetMaxCodiceAPIbyTipoAndFunzione( $p_sTipo, $p_sFunzione )
        {
        $query = "SELECT MAX(codice) AS max_codice_tipo FROM luda_server_api_codici WHERE tipo='" .$p_sTipo. "' AND funzione = '" .$p_sFunzione. "' ";
        echo "QUERY = [" .$query. "]<BR>\n";
        $this->Query_01( $query );
        $result = $this->Fetch_01();
        //var_dump( $result );
        //exit();
        $max_codice_tipo = $result->max_codice_tipo;
        return $max_codice_tipo;
    }//GetMaxCodiceAPIbyTipoAndFunction    
///////////////////////////////////////////////////////////////////
        
    function Table_Print_01( $p_sTableName )
        {
        $loDB = new cLUDA_DB();
        $query = "SELECT * FROM " . $p_sTableName;
        $result = $loDB->Query_01($query);
        $num_records = $loDB->RecordCount_01();
        $columns_name = $loDB->ColumnsName_01();
        //var_dump( $columns_name );
        //exit();
        
        echo "Tabella <b>'" .$p_sTableName. "'</b> &bull; Numero di records = <b>[" . $num_records . "]</b><br>";
    
        // Select queries return a resultset.
        if ( ! is_null($result) ) 
            {
            //printf( "Il recordset contiene [%d] righe.\n", $num_records );
            echo "<TABLE border='1' >";
            
            // Header.
            $line  = "";
            $line .= "<TR class='cl_table_header_columns_name' >";
            foreach( $columns_name as $col_num => $col_name )
                {
                $line .= "<TD >" .$col_name. "</TD>";
                }
            $line .= "</TR>";
            echo $line;
          
            // Data.
            while( $obj = $loDB->Fetch_01() )
                {
                //var_dump( $obj );
                $line ="";
                $line.="<TR >";
                foreach( $columns_name as $col_num => $col_name )
                    {
                    $line .= "<TD >" . $obj->$col_name . "</TD>";
                    }
                $line.="</TR>";
                echo $line;
                }
            echo "</TABLE>";
            }
          
        }//Table_Print_01
///////////////////////////////////////////////////////////////////
    
    public function Finish_01( )
        {//Finish_01
                            
        //
        $this->mDB_result->close();
       
        $this->mDB_conn->close();
        }//Finish_01
///////////////////////////////////////////////////////////////////

    // method declaration
    public function displayVar() {
        echo $this->var;
    }
///////////////////////////////////////////////////////////////////
*/







         