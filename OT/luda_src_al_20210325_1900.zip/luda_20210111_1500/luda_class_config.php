<?php
///////////////////////////////////////////////////////////////////
// 
// BoF :: "luda_class_config.PHP"
// 
// 2020-04-20 :: 21:00
//
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////

Class cLUDA_Config
    {

    //private $m_sSelfTipo = "";

    // Database object.
    private $m_oDB = NULL;

    //function __construct( $p_sSelfTipo ) 
    function __construct( ) 
        {
        //print "cLUDA_Config :: constructor<br>\n";
        $this->m_oDB = new cLUDA_DB();        
        }//__construct

    function __destruct() 
        {
        $this->m_oDB->Finish_01();
        }//__destruct
///////////////////////////////////////////////////////////////////

    public function Get_ByName_01( $p_sConfigName )
        {
        $query = "SELECT value as luda_server_configs__value FROM luda_server_configs WHERE name = '" .$p_sConfigName. "' ";
        //echo "QUERY = [" . $query  . "]<br>";
        $this->m_oDB->Query_01($query);
        $num_records = $this->m_oDB->RecordCount_01();
        //echo "Get_ByName_01: Numero di righe ritornate = " . $num_records  . "<br>";
        $recordset = $this->m_oDB->Result_01();
        //var_dump( $recordset );
        $record = $this->m_oDB->Fetch_01();
        //var_dump( $record );
        $luda_server_configs__value = $record->luda_server_configs__value;
        //var_dump( $luda_server_configs__value );
        //exit();        
        return $luda_server_configs__value;        
        }//Get_ByName_01
///////////////////////////////////////////////////////////////////
    
    public function Put_ByName_01( $p_sConfigName, $p_sConfigValue )
        {
        //    if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_SRV ) { $this->_Put_SelfSrv_01($p_iI,$p_iK); }  
        //    if( $this->m_sSelfTipo==LUDA_CONSTANT_SERVER_TIPO_UDA ) { $this->_Put_SelfUda_01($p_iI,$p_iK); }  
        $query = "UPDATE luda_server_configs SET value = '" .$p_sConfigValue. "' WHERE name = '" .$p_sConfigName. "' ";
        //echo "QUERY = [" . $query  . "]<br>";
        $this->m_oDB->Query_01($query);
$luda_server_configs__value = $this->Get_ByName_01($p_sConfigName);
//var_dump( $luda_server_configs__value );
//exit();        
return $luda_server_configs__value;        

        }//Put_ByName_01
///////////////////////////////////////////////////////////////////
    
 


    }//cLUDA_Config
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// EoF :: "luda_class_config.PHP"
///////////////////////////////////////////////////////////////////
?> 